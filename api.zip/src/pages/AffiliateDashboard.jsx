import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { getRememberedAffiliate, clearRememberedAffiliate } from '../utils/affiliateTracking'
import hidratanteProductImage from '../assets/cart/hidratante.webp'
import stickProductImage from '../assets/cart/stick-clareador.webp'

function brl(value) {
  return `R$ ${Number(value || 0).toFixed(2).replace('.', ',')}`
}

function monthLabel(value) {
  if (!value) return ''
  const [year, month] = value.split('-').map(Number)
  return new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' })
    .format(new Date(year, month - 1, 1))
    .replace(/^./, char => char.toUpperCase())
}

function shortDate(value) {
  const [year, month, day] = value.split('-')
  return `${day}/${month}`
}

function whatsappUrl(value) {
  const digits = String(value || '').replace(/\D/g, '')
  if (!digits) return ''
  const normalized = digits.startsWith('55') ? digits : `55${digits}`
  return `https://wa.me/${normalized}`
}

function withdrawalStatusLabel(status) {
  if (status === 'approved') return 'Aprovado'
  if (status === 'paid') return 'Pago'
  if (status === 'processing') return 'Processando Pix'
  if (status === 'failed') return 'Falhou'
  if (status === 'rejected') return 'Recusado'
  if (status === 'cancelled') return 'Cancelado'
  return 'Pendente'
}

function productPurchaseStatusLabel(status, freightPaid = true) { if (status === 'approved') return 'Aprovado'; if (status === 'shipped' || status === 'pending') return 'Reserva'; if (status === 'rejected') return 'Recusado · Reserva liberada'; if (status === 'cancelled') return 'Cancelado · Reserva liberada'; return freightPaid ? 'Reserva · Frete pago' : 'Reserva · Frete pendente' }

function boostStatusLabel(status) {
  if (status === 'active') return 'Ativo'
  if (status === 'completed') return 'Concluído'
  if (status === 'cancelled') return 'Saldo devolvido'
  return 'Reservado na fila'
}

async function api(path, options = {}) {
  const previewId = new URLSearchParams(window.location.search).get('adminPreviewId')
  const isPreview = Boolean(previewId)
  if (isPreview && String(options.method || 'GET').toUpperCase() !== 'GET') {
    throw new Error('Modo de Administrador - Cuidado: ações que alteram dados estão bloqueadas nesta visualização.')
  }
  let requestPath = path
  if (isPreview && path.startsWith('/api/affiliate/dashboard')) {
    const separator = path.includes('?') ? '&' : '?'
    requestPath = `${path}${separator}adminPreviewId=${encodeURIComponent(previewId)}`
  }
  const response = await fetch(requestPath, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  })
  const raw = await response.text().catch(() => '')
  let data = {}
  try { data = raw ? JSON.parse(raw) : {} } catch { data = {} }
  if (!response.ok) {
    const detail = data.error || data.message || data.msg || (raw && raw.slice(0, 180))
    throw new Error(detail ? `Falha na operação (HTTP ${response.status}): ${detail}` : `Falha na operação (HTTP ${response.status}).`)
  }
  if (!raw) return {}
  return data
}

function friendlyAffiliateRegistrationError(message, form) {
  const raw = String(message || '').replace(/.*?HTTP \d{3}\):?\s*/i, '').trim()
  const lower = raw.toLowerCase()
  const cpf = String(form?.cpf || '').replace(/\D/g, '')
  const email = String(form?.email || '').trim()
  const password = String(form?.password || '')

  if (/cpf/.test(lower) || /documento/.test(lower)) {
    if (/já está cadastrado|ja esta cadastrado|already (been )?registered|duplicate/.test(lower)) {
      return 'Este CPF já está cadastrado. Confira os dados ou entre na sua conta.'
    }
    return 'O CPF informado parece incorreto. Confira os números e digite um CPF válido.'
  }
  if (/e-?mail|email/.test(lower)) {
    if (/já cadastrado|ja cadastrado|already registered|already exists|user exists/.test(lower)) {
      return 'Este e-mail já está cadastrado. Tente entrar na sua conta ou use outro e-mail válido.'
    }
    return 'Não foi possível cadastrar esse e-mail. Confira se está escrito corretamente e tente um e-mail válido.'
  }
  if (/password|senha|weak password|characters|caracteres/.test(lower)) {
    if (password.length < 8 || /at least 8|mínimo de 8|minimum.*8|too short|shorter than/.test(lower)) {
      return 'A senha precisa ter pelo menos 8 caracteres. Escolha uma senha mais longa e tente novamente.'
    }
    if (/leaked|compromised|pwned|common password|senha.*comum/.test(lower)) {
      return 'Essa senha não é segura o suficiente. Escolha outra senha, evitando combinações muito comuns.'
    }
    return 'Não foi possível cadastrar essa senha. Use uma senha com pelo menos 8 caracteres e tente outra combinação.'
  }
  if (/whatsapp|telefone/.test(lower)) return 'Confira o número do WhatsApp e tente novamente.'
  if (/nome/.test(lower)) return 'Informe seu nome para continuar o cadastro.'
  if (/fetch|network|failed to|servidor|temporariamente|internal server/.test(lower)) {
    return 'Não foi possível concluir o cadastro agora. Confira sua conexão e tente novamente em instantes.'
  }
  if (cpf.length !== 11) return 'Confira o CPF informado e digite um CPF válido.'
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Digite um e-mail válido para continuar.'
  if (password.length < 8) return 'A senha precisa ter pelo menos 8 caracteres.'
  return 'Não foi possível concluir seu cadastro. Confira os dados e tente novamente.'
}

function levelTone(key) {
  if (key === 'gold') return 'from-amber-200 via-yellow-100 to-amber-50'
  if (key === 'silver') return 'from-zinc-200 via-white to-zinc-100'
  if (key === 'bronze') return 'from-orange-200 via-orange-100 to-amber-50'
  return 'from-pink-100 via-white to-zinc-50'
}

function levelAccent(key) {
  if (key === 'gold') return 'text-amber-700'
  if (key === 'silver') return 'text-zinc-600'
  if (key === 'bronze') return 'text-orange-700'
  return 'text-pink-500'
}

export default function AffiliateDashboard() {
  const adminPreviewId = new URLSearchParams(window.location.search).get('adminPreviewId')
  const isAdminPreview = Boolean(adminPreviewId)
  const [affiliateNavOpen, setAffiliateNavOpen] = useState(false)
  const scrollToAffiliateSection = (sectionId) => {
    setAffiliateNavOpen(false)
    window.requestAnimationFrame(() => {
      const section = document.getElementById(sectionId)
      if (section) section.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  }
  const [affiliate, setAffiliate] = useState(null)
  const [installHelpOpen, setInstallHelpOpen] = useState(false)
  const [installPrompt, setInstallPrompt] = useState(null)
  const [isIosDevice, setIsIosDevice] = useState(false)
  const [isSafariBrowser, setIsSafariBrowser] = useState(false)
  const [isAndroidDevice, setIsAndroidDevice] = useState(false)
  const [isStandaloneApp, setIsStandaloneApp] = useState(false)
  const [pushPromptOpen, setPushPromptOpen] = useState(false)
  const [pushBusy, setPushBusy] = useState(false)
  const [pushMessage, setPushMessage] = useState('')
  const [pushDismissed, setPushDismissed] = useState(false)
  const [dashboard, setDashboard] = useState(null)
  const [selectedMonth, setSelectedMonth] = useState('all')
  const [registerMode, setRegisterMode] = useState(false)
  const [welcomeMotherOpen, setWelcomeMotherOpen] = useState(false)
  const [welcomeMotherPending, setWelcomeMotherPending] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', password: '', whatsapp: '', cpf: '' })
  const [registerSurname, setRegisterSurname] = useState('')
  const [login, setLogin] = useState({ email: typeof window !== 'undefined' ? (localStorage.getItem('she_affiliate_saved_email') || '') : '', password: '' })
  const [rememberLogin, setRememberLogin] = useState(typeof window !== 'undefined' && localStorage.getItem('she_affiliate_remember_login') === 'true')
  const [showLoginPassword, setShowLoginPassword] = useState(false)
  const [showRegisterPassword, setShowRegisterPassword] = useState(false)
  const [forgotOpen, setForgotOpen] = useState(false)
  const [forgotEmail, setForgotEmail] = useState('')
  const [forgotBusy, setForgotBusy] = useState(false)
  const [forgotMessage, setForgotMessage] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const [productShop, setProductShop] = useState({ purchases: [], prices: null })
  const [purchaseProduct, setPurchaseProduct] = useState('')
  const [purchaseForm, setPurchaseForm] = useState({ name: '', cpf: '', cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '', email: '', phone: '', notes: '' })
  const [purchaseCepLoading, setPurchaseCepLoading] = useState(false)
  const [purchaseCepError, setPurchaseCepError] = useState('')
  const [purchaseBusy, setPurchaseBusy] = useState(false)
  const [purchaseMessage, setPurchaseMessage] = useState('')



  useEffect(() => {
    if (!dashboard?.affiliate?.id) return
    let cancelled = false
    // A rota existente lê os preços diretamente de affiliate_settings no Supabase.
    // Usamos a mesma resposta para preços e solicitações, sem depender de campos
    // derivados no dashboard e sem criar uma nova Serverless Function.
    api('/api/affiliate/product-purchases')
      .then(data => {
        if (cancelled) return
        const hydrant = Number(data?.prices?.hydrant)
        const stick = Number(data?.prices?.stick)
        const validPrices = Number.isFinite(hydrant) && hydrant > 0 && Number.isFinite(stick) && stick > 0
        setProductShop({
          prices: validPrices ? { hydrant, stick } : null,
          purchases: Array.isArray(data?.purchases) ? data.purchases : [],
        })
      })
      .catch(() => {
        if (!cancelled) setProductShop(current => ({ ...current, prices: null }))
      })
    return () => { cancelled = true }
  }, [dashboard?.affiliate?.id])

  useEffect(() => {
    const cep = String(purchaseForm.cep || '').replace(/\D/g, '')
    if (cep.length !== 8) {
      setPurchaseCepError('')
      setPurchaseCepLoading(false)
      setPurchaseForm(current => ({ ...current, street: '', neighborhood: '', city: '', state: '' }))
      return
    }
    let cancelled = false
    setPurchaseCepLoading(true)
    setPurchaseCepError('')
    fetch(`https://viacep.com.br/ws/${cep}/json/`)
      .then(async response => {
        if (!response.ok) throw new Error('Não foi possível consultar o CEP.')
        return response.json()
      })
      .then(data => {
        if (cancelled) return
        if (data.erro) throw new Error('CEP não encontrado. Confira os números digitados.')
        setPurchaseForm(current => ({
          ...current,
          street: data.logradouro || '',
          neighborhood: data.bairro || '',
          city: data.localidade || '',
          state: data.uf || '',
        }))
      })
      .catch(err => { if (!cancelled) setPurchaseCepError(err.message || 'Não foi possível consultar o CEP.') })
      .finally(() => { if (!cancelled) setPurchaseCepLoading(false) })
    return () => { cancelled = true }
  }, [purchaseForm.cep])

  const submitProductPurchase = async (event) => {
    event.preventDefault()
    if (!purchaseProduct) return
    setPurchaseBusy(true)
    setPurchaseMessage('')
    try {
      const result = await api('/api/affiliate/product-purchases', {
        method: 'POST',
        body: JSON.stringify({ action: 'purchase', product: purchaseProduct, form: { ...purchaseForm, address: [purchaseForm.street, purchaseForm.number ? `nº ${purchaseForm.number}` : '', purchaseForm.complement, purchaseForm.neighborhood, [purchaseForm.city, purchaseForm.state].filter(Boolean).join(' - '), `CEP ${purchaseForm.cep}`].filter(Boolean).join(', ') } }),
      })
      setPurchaseMessage(result?.freight?.paymentUrl ? 'Solicitação criada e saldo do produto reservado. Pague o frete de R$ 16,00 no card abaixo para liberar o envio.' : 'Solicitação criada e saldo do produto reservado. O link do frete ainda não foi gerado; use a opção de gerar link na solicitação.')
      setPurchaseProduct('')
      const [freshDashboard, shop] = await Promise.all([
        api(`/api/affiliate/dashboard?month=${encodeURIComponent(selectedMonth || 'all')}`, { cache: 'no-store' }),
        api('/api/affiliate/product-purchases', { cache: 'no-store' }),
      ])
      setDashboard(freshDashboard)
      setProductShop(shop)
      setPurchaseForm({ name: '', cpf: '', cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '', email: '', phone: '', notes: '' })
    } catch (e) {
      setPurchaseMessage(e.message || 'Não foi possível solicitar a compra.')
    } finally {
      setPurchaseBusy(false)
    }
  }

  const createFreightPaymentLink = async (purchaseId) => {
    setPurchaseBusy(true)
    setPurchaseMessage('Gerando link de pagamento do frete…')
    try {
      await api('/api/affiliate/product-purchases', { method: 'POST', body: JSON.stringify({ action: 'create_freight_charge', id: purchaseId }) })
      const shop = await api('/api/affiliate/product-purchases')
      setProductShop(shop)
      setPurchaseMessage('Link de pagamento atualizado. Após a confirmação da Woovi, o envio será liberado no painel administrativo.')
    } catch (e) { setPurchaseMessage(e.message || 'Não foi possível gerar o link de pagamento.') }
    finally { setPurchaseBusy(false) }
  }

  // Mostra a boas-vindas depois que o cadastro conclui e a equipe é carregada.
  useEffect(() => {
    const parent = dashboard?.team?.parent
    if (!welcomeMotherPending || !affiliate?.id || !parent) return
    const key = `she-welcome-mother-shown-${affiliate.id}`
    try {
      if (window.localStorage.getItem(key) === '1') {
        setWelcomeMotherPending(false)
        return
      }
      window.localStorage.setItem(key, '1')
    } catch {}
    setWelcomeMotherOpen(true)
    setWelcomeMotherPending(false)
  }, [welcomeMotherPending, affiliate?.id, dashboard?.team?.parent])
  const [busy, setBusy] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const [syncMessage, setSyncMessage] = useState('')
  const [withdrawAmount, setWithdrawAmount] = useState('')
  const [withdrawBusy, setWithdrawBusy] = useState(false)
  const [withdrawMessage, setWithdrawMessage] = useState('')
  const [teamWithdrawAmount, setTeamWithdrawAmount] = useState('')
  const [teamWithdrawBusy, setTeamWithdrawBusy] = useState(false)
  const [teamWithdrawMessage, setTeamWithdrawMessage] = useState('')
  const [teamSearch, setTeamSearch] = useState('')
  const [teamCode, setTeamCode] = useState('')
  const [teamJoinBusy, setTeamJoinBusy] = useState(false)
  const [teamJoinMessage, setTeamJoinMessage] = useState('')
  const [teamBoost, setTeamBoost] = useState(null)
  const [teamBoostBusy, setTeamBoostBusy] = useState(false)
  const [teamBoostMessage, setTeamBoostMessage] = useState('')
  const [boostConfirmPlan, setBoostConfirmPlan] = useState(null)
  const [boostTermsAccepted, setBoostTermsAccepted] = useState(false)
  const [teamReservation, setTeamReservation] = useState(null)
  const [teamLookup, setTeamLookup] = useState(null)
  const [teamLookupBusy, setTeamLookupBusy] = useState(false)
  const [teamLookupMessage, setTeamLookupMessage] = useState('')
  const [teamConfirmOpen, setTeamConfirmOpen] = useState(false)
  const [teamConfirmParent, setTeamConfirmParent] = useState(null)
  const [teamConfirmType, setTeamConfirmType] = useState('manual')
  const [videoSubmissions, setVideoSubmissions] = useState([])
  const [videoUrl, setVideoUrl] = useState('')
  const [videoTermsOpen, setVideoTermsOpen] = useState(false)
  const [videoTermsAccepted, setVideoTermsAccepted] = useState(false)
  const [videoBusy, setVideoBusy] = useState(false)
  const [videoMessage, setVideoMessage] = useState('')
  const [pixKey, setPixKey] = useState('')
  const [pixKeyType, setPixKeyType] = useState('CPF')
  const [pixOpen, setPixOpen] = useState(false)
  const [pixBusy, setPixBusy] = useState(false)
  const [pixMessage, setPixMessage] = useState('')
  const [profileOpen, setProfileOpen] = useState(false)
  const [profileForm, setProfileForm] = useState({ email: '', cpf: '', whatsapp: '', password: '' })
  const [profileBusy, setProfileBusy] = useState(false)
  const [profileMessage, setProfileMessage] = useState('')
  const [levelHelpOpen, setLevelHelpOpen] = useState(false)
  const [fixedHelpOpen, setFixedHelpOpen] = useState(false)
  const [videoHelpOpen, setVideoHelpOpen] = useState(false)
  const [boostHelpOpen, setBoostHelpOpen] = useState(false)
  const [registerTermsCardOpen, setRegisterTermsCardOpen] = useState(false)
  const [registerTermsOpen, setRegisterTermsOpen] = useState(false)
  const [linkSlug, setLinkSlug] = useState('')
  const [linkBusy, setLinkBusy] = useState(false)
  const [linkMessage, setLinkMessage] = useState('')
  const [welcomeLinkOpen, setWelcomeLinkOpen] = useState(false)
  const [welcomeLinkCopyMessage, setWelcomeLinkCopyMessage] = useState('')
  const chartScrollRef = useRef(null)

  useEffect(() => {
    const node = chartScrollRef.current
    const chartData = dashboard?.chart || []
    if (!node || !chartData.length) return
    requestAnimationFrame(() => { node.scrollLeft = node.scrollWidth })
  }, [dashboard?.chart])

  const load = async ({ sync = false, month = selectedMonth } = {}) => {
    try {
      const dashboardUrl = `/api/affiliate/dashboard?month=${encodeURIComponent(month || 'all')}`
      const data = await api(dashboardUrl)
      setAffiliate(data.affiliate)
      setPixKey(data.affiliate?.pix_key || '')
      setPixKeyType(data.affiliate?.pix_key_type || 'CPF')
      setDashboard(data)
      try {
        const boostData = await api('/api/affiliate/dashboard?boost=1')
        setTeamBoost(boostData)
        if (boostData.boost?.status === 'queued' || boostData.boost?.status === 'active') setTeamReservation(null)
      } catch {
        setTeamBoost(null)
      }
      try {
        const videoData = await api('/api/affiliate/dashboard?videos=1')
        setVideoSubmissions(videoData.videos || [])
      } catch {
        setVideoSubmissions([])
      }
      setLoading(false)

      if (sync) {
        setSyncing(true)
        setSyncMessage('Atualizando vendas e painel…')
        try {
          const result = await api('/api/affiliate/yampi-sync', { method: 'POST', body: '{}' })
          if (result.configured === false) {
            setSyncMessage('Integração de vendas ainda não configurada.')
          } else {
            setSyncMessage(`${result.synced || 0} pedido(s) sincronizado(s). Atualizando painel…`)
          }
        } catch (e) {
          setSyncMessage(e.message || 'Não foi possível atualizar as vendas; atualizando os demais dados…')
        }
        // Atualiza todos os dados do painel, não somente os pedidos da Yampi.
        try {
          const [freshDashboard, boostData, videoData, shopData] = await Promise.all([
            api(dashboardUrl, { cache: 'no-store' }),
            api('/api/affiliate/dashboard?boost=1', { cache: 'no-store' }).catch(() => null),
            api('/api/affiliate/dashboard?videos=1', { cache: 'no-store' }).catch(() => ({ videos: [] })),
            api('/api/affiliate/product-purchases', { cache: 'no-store' }).catch(() => null),
          ])
          setAffiliate(freshDashboard.affiliate)
          setPixKey(freshDashboard.affiliate?.pix_key || '')
          setPixKeyType(freshDashboard.affiliate?.pix_key_type || 'CPF')
          setDashboard(freshDashboard)
          if (boostData) setTeamBoost(boostData)
          setVideoSubmissions(videoData?.videos || [])
          if (shopData) setProductShop(shopData)
          setSyncMessage(current => current && current.includes('pedido(s) sincronizado(s)') ? current.replace('Atualizando painel…', 'Painel atualizado.') : current)
        } catch (e) {
          setSyncMessage(e.message || 'Não foi possível atualizar todos os dados do painel.')
        } finally {
          setSyncing(false)
        }
      }
    } catch {
      setAffiliate(null)
      setLoading(false)
    }
  }

  useEffect(() => {
    const numericValue = String(teamCode || '').trim()
    if (!affiliate?.id || !numericValue || !/^\d+$/.test(numericValue) || teamReservation) {
      setTeamLookup(null)
      setTeamLookupMessage('')
      setTeamLookupBusy(false)
      return undefined
    }

    let cancelled = false
    const timeout = setTimeout(async () => {
      setTeamLookupBusy(true)
      setTeamLookupMessage('')
      try {
        const result = await api('/api/affiliate/dashboard', {
          method: 'POST',
          body: JSON.stringify({ action: 'team_lookup', parentId: Number(numericValue) }),
        })
        if (cancelled) return
        setTeamLookup(result.parent || null)
        setTeamLookupMessage(result.parent ? '' : (result.message || 'Não encontramos uma afiliada ativa com esse ID.'))
      } catch (e) {
        if (cancelled) return
        setTeamLookup(null)
        setTeamLookupMessage(e.message || 'Não foi possível consultar esse ID agora.')
      } finally {
        if (!cancelled) setTeamLookupBusy(false)
      }
    }, 350)

    return () => {
      cancelled = true
      clearTimeout(timeout)
    }
  }, [teamCode, teamReservation, affiliate?.id])

  useEffect(() => {
    const ua = window.navigator.userAgent || ''
    const ios = /iPad|iPhone|iPod/.test(ua) || (window.navigator.platform === 'MacIntel' && window.navigator.maxTouchPoints > 1)
    const android = /Android/i.test(ua)
    const safari = /Safari/i.test(ua) && !/(CriOS|FxiOS|EdgiOS|OPiOS|Chrome|Chromium|Firefox|DuckDuckGo|GSA)/i.test(ua)
    // O APK Android abre o painel dentro de um WebView nativo, que não usa o display-mode
    // standalone da PWA. O user-agent padrão do Android WebView inclui "wv" e/ou Version/4.0.
    // Assim o botão de instalação some dentro do APK, sem esconder no Chrome comum.
    const inAndroidAppWebView = android && (/(?:\bwv\b|;\s*wv\))/i.test(ua) || /Android.*Version\/4\.0.*Chrome\//i.test(ua))
    const standalone = window.matchMedia?.('(display-mode: standalone)').matches || window.navigator.standalone === true || ['pwa', 'android-app'].includes(new URLSearchParams(window.location.search).get('source')) || inAndroidAppWebView
    setIsIosDevice(ios)
    setIsAndroidDevice(android)
    setIsSafariBrowser(safari)
    setIsStandaloneApp(Boolean(standalone))
    const onBeforeInstall = (event) => {
      event.preventDefault()
      setInstallPrompt(event)
    }
    const onInstalled = () => {
      setInstallPrompt(null)
      setInstallHelpOpen(false)
      setIsStandaloneApp(true)
    }
    window.addEventListener('beforeinstallprompt', onBeforeInstall)
    window.addEventListener('appinstalled', onInstalled)
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {})
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall)
      window.removeEventListener('appinstalled', onInstalled)
    }
  }, [])

  useEffect(() => {
    if (isAdminPreview || !affiliate?.id || !isStandaloneApp || isAndroidDevice || pushDismissed) return
    if (!('Notification' in window) || Notification.permission !== 'default') return
    // Não bloqueia a exibição do convite por uma detecção prematura de PushManager;
    // a compatibilidade completa é verificada quando a afiliada toca em Ativar.
    const key = `she-push-prompt-dismissed-${affiliate.id}`
    try { if (window.sessionStorage.getItem(key) === '1') return } catch {}
    const timer = window.setTimeout(() => setPushPromptOpen(true), 1400)
    return () => window.clearTimeout(timer)
  }, [affiliate?.id, isStandaloneApp, isAndroidDevice, pushDismissed])

  const base64UrlToUint8Array = (value) => {
    const padding = '='.repeat((4 - value.length % 4) % 4)
    const base64 = (value + padding).replace(/-/g, '+').replace(/_/g, '/')
    const raw = window.atob(base64)
    return Uint8Array.from([...raw].map(char => char.charCodeAt(0)))
  }

  const enablePushNotifications = async () => {
    setPushBusy(true)
    setPushMessage('')
    try {
      if (!isStandaloneApp) throw new Error('Adicione a She à Tela de Início e abra pelo ícone para ativar as notificações no iPhone.')
      if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) throw new Error('Este dispositivo ou navegador não oferece suporte a notificações push.')
      const config = await api('/api/affiliate/push-subscription')
      if (!config.publicKey) throw new Error('As notificações ainda estão sendo configuradas. Tente novamente mais tarde.')
      const permission = await Notification.requestPermission()
      if (permission !== 'granted') {
        setPushPromptOpen(false)
        setPushDismissed(true)
        window.sessionStorage.setItem(`she-push-prompt-dismissed-${affiliate.id}`, '1')
        setPushMessage('As notificações não foram autorizadas. Você poderá ativá-las nas configurações do dispositivo.')
        return
      }
      const registration = await navigator.serviceWorker.ready
      let subscription = await registration.pushManager.getSubscription()
      if (!subscription) subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: base64UrlToUint8Array(config.publicKey) })
      await api('/api/affiliate/push-subscription', { method: 'POST', body: JSON.stringify({ subscription: subscription.toJSON() }) })
      setPushPromptOpen(false)
      setPushDismissed(true)
      setPushMessage('Notificações ativadas! Você receberá novidades importantes da sua equipe.')
    } catch (err) {
      setPushMessage(err.message || 'Não foi possível ativar as notificações.')
    } finally {
      setPushBusy(false)
    }
  }

  const dismissPushPrompt = () => {
    setPushPromptOpen(false)
    setPushDismissed(true)
    if (affiliate?.id) window.sessionStorage.setItem(`she-push-prompt-dismissed-${affiliate.id}`, '1')
  }

  const handleInstallApp = async () => {
    if (isAndroidDevice) {
      setInstallHelpOpen(true)
      return
    }
    if (isIosDevice && !isSafariBrowser) {
      setInstallHelpOpen(true)
      return
    }
    if (installPrompt && !isIosDevice) {
      installPrompt.prompt()
      try { await installPrompt.userChoice } catch {}
      setInstallPrompt(null)
      return
    }
    setInstallHelpOpen(true)
  }

  useEffect(() => { load({ sync: !isAdminPreview }) }, [])


  const submitLogin = async (event) => {
    event.preventDefault()
    if (rememberLogin) { localStorage.setItem('she_affiliate_saved_email', login.email); localStorage.setItem('she_affiliate_remember_login', 'true') }
    else { localStorage.removeItem('she_affiliate_saved_email'); localStorage.removeItem('she_affiliate_remember_login') }
    setBusy(true); setError('')
    try {
      await api('/api/affiliate/login', { method: 'POST', body: JSON.stringify(login) })
      await load({ sync: true })
    } catch (e) {
      setError(e.message)
    } finally { setBusy(false) }
  }

  const submitForgotPassword = async (event) => {
    event?.preventDefault()
    setForgotBusy(true)
    setForgotMessage('')
    try {
      const email = String(forgotEmail || '').trim().toLowerCase()
      if (!email) throw new Error('Informe seu e-mail.')
      const result = await api('/api/affiliate/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email }),
      })
      setForgotMessage(result.message || 'Se o e-mail estiver cadastrado, você receberá o link para redefinir sua senha.')
    } catch (e) {
      setForgotMessage(e.message || 'Não foi possível enviar o link de recuperação.')
    } finally {
      setForgotBusy(false)
    }
  }

  const submitRegister = (event) => {
    event.preventDefault()
    setError('')
    setRegisterTermsCardOpen(true)
  }

  const acceptRegisterTermsAndCreate = async () => {
    setBusy(true); setError('')
    try {
      await api('/api/affiliate/register', { method: 'POST', body: JSON.stringify({ ...form, referralSlug: getRememberedAffiliate() }) })
      clearRememberedAffiliate()
      setRegisterTermsCardOpen(false)
      setRegisterTermsOpen(false)
      setWelcomeMotherPending(true)
      await load({ sync: true })
    } catch (e) {
      setError(friendlyAffiliateRegistrationError(e.message, form))
    } finally { setBusy(false) }
  }

  const createAffiliateLink = async (event) => {
    event.preventDefault()
    setLinkBusy(true)
    setLinkMessage('')
    try {
      const result = await api('/api/affiliate/dashboard', {
        method: 'POST',
        body: JSON.stringify({ action: 'create_link', slug: linkSlug }),
      })
      setAffiliate(current => current ? { ...current, slug: result.affiliate?.slug || '' } : current)
      setLinkSlug('')
      setLinkMessage('Seu link foi criado com sucesso.')
      await load({ sync: false })
      setWelcomeLinkCopyMessage('')
      setWelcomeLinkOpen(true)
    } catch (e) {
      setLinkMessage(e.message || 'Não foi possível criar seu link.')
    } finally {
      setLinkBusy(false)
    }
  }

  const openProfile = () => {
    setProfileForm({ email: affiliate?.email || '', cpf: affiliate?.cpf || '', whatsapp: affiliate?.whatsapp || '', password: '' })
    setProfileMessage('')
    setProfileOpen(true)
  }

  const saveProfile = async (event) => {
    event.preventDefault()
    setProfileBusy(true)
    setProfileMessage('')
    try {
      const result = await api('/api/affiliate/dashboard', {
        method: 'POST',
        body: JSON.stringify({ action: 'update_profile', ...profileForm }),
      })
      setAffiliate(current => current ? { ...current, ...result.affiliate } : current)
      setProfileForm(current => ({ ...current, password: '' }))
      setProfileMessage(result.passwordChanged ? 'Dados e senha atualizados com sucesso.' : 'Dados atualizados com sucesso.')
    } catch (e) {
      setProfileMessage(e.message || 'Não foi possível atualizar seus dados.')
    } finally {
      setProfileBusy(false)
    }
  }

  const logout = async () => {
    await api('/api/affiliate/logout', { method: 'POST' }).catch(() => {})
    setAffiliate(null)
    setDashboard(null)
  }

  const changeSelectedMonth = async (value) => {
    setSelectedMonth(value)
    try {
      const data = await api(`/api/affiliate/dashboard?month=${encodeURIComponent(value || 'all')}`)
      setDashboard(data)
    } catch (e) {
      setError(e.message || 'Não foi possível carregar os indicadores do mês.')
    }
  }

  const requestWithdraw = async (event) => {
    event.preventDefault()
    setWithdrawBusy(true)
    setWithdrawMessage('')
    try {
      const amount = Number(String(withdrawAmount).replace(',', '.'))
      await api('/api/affiliate/withdraw', {
        method: 'POST',
        body: JSON.stringify({ amount, source: 'personal' }),
      })
      setWithdrawAmount('')
      setWithdrawMessage(`Solicitação enviada. ${brl(amount)} ficou reservado para análise.`)
      const refreshed = await api(`/api/affiliate/dashboard?month=${encodeURIComponent(selectedMonth || 'all')}`)
      setDashboard(refreshed)
    } catch (e) {
      setWithdrawMessage(e.message || 'Não foi possível solicitar o saque.')
    } finally {
      setWithdrawBusy(false)
    }
  }
  const openTeamConfirmation = (parent, type) => {
    setTeamConfirmParent(parent)
    setTeamConfirmType(type)
    setTeamConfirmOpen(true)
    setTeamJoinMessage('')
    setTeamBoostMessage('')
  }

  const closeTeamConfirmation = () => {
    setTeamConfirmOpen(false)
  }

  // O primeiro clique abre a confirmação; a entrada e o aceite dos termos ocorrem ao clicar em “Aceitar e entrar na equipe”.
  const joinTeam = (event) => {
    event.preventDefault()
    if (teamReservation?.reservationId) {
      openTeamConfirmation({
        id: Number(teamReservation.parentId),
        parentId: Number(teamReservation.parentId),
        name: teamReservation.parentName,
        parentName: teamReservation.parentName,
      }, 'boost')
      return
    }
    const numericId = Number(String(teamCode).trim())
    if (!teamLookup || Number(teamLookup.id) !== numericId) {
      setTeamJoinMessage('Aguarde a confirmação do nome da afiliada mãe antes de continuar.')
      return
    }
    openTeamConfirmation(teamLookup, 'manual')
  }

  const confirmTeamJoin = async () => {
    setTeamJoinBusy(true)
    setTeamJoinMessage('')
    setTeamBoostMessage('')
    try {
      // Clicar em “Aceitar e entrar na equipe” registra o aceite dos termos exibidos.
      const commonTerms = {
        teamTermsVersion: '1.1',
        teamTermsAccepted: true,
      }
      let result
      if (teamConfirmType === 'boost' && teamReservation?.reservationId) {
        result = await api('/api/affiliate/dashboard', {
          method: 'POST',
          body: JSON.stringify({ action: 'boost_confirm', reservationId: teamReservation.reservationId, ...commonTerms }),
        })
      } else {
        const numericId = Number(teamConfirmParent?.id || teamConfirmParent?.parentId || teamCode)
        if (!Number.isInteger(numericId) || numericId <= 0) throw new Error('Informe um ID numérico de afiliada mãe válido.')
        result = await api('/api/affiliate/dashboard', {
          method: 'POST',
          body: JSON.stringify({ teamParentId: numericId, ...commonTerms }),
        })
      }
      setAffiliate(current => current ? { ...current, team_parent_id: result.affiliate?.team_parent_id || result.result?.parentId || true } : current)
      setTeamJoinMessage('Você entrou na equipe com sucesso.')
      setWelcomeLinkOpen(false)
      setTeamCode('')
      setTeamLookup(null)
      setTeamLookupMessage('')
      setTeamReservation(null)
      setTeamConfirmOpen(false)
      const refreshed = await api(`/api/affiliate/dashboard?month=${encodeURIComponent(selectedMonth || 'all')}`)
      setDashboard(refreshed)
      try { setTeamBoost(await api('/api/affiliate/dashboard?boost=1')) } catch {}
    } catch (e) {
      setTeamJoinMessage(e.message || 'Não foi possível entrar na equipe.')
    } finally {
      setTeamJoinBusy(false)
    }
  }

  const findTeam = async () => {
    setTeamBoostBusy(true)
    setTeamBoostMessage('')
    setTeamJoinMessage('')
    try {
      const result = await api('/api/affiliate/dashboard', { method: 'POST', body: JSON.stringify({ action: 'boost_find' }) })
      const reservation = result.reservation || null
      if (!reservation?.reservationId || !reservation?.parentId) throw new Error('Não foi possível confirmar a afiliada selecionada.')
      const normalized = {
        ...reservation,
        parentId: Number(reservation.parentId),
        parentName: reservation.parentName || 'Afiliada mãe',
      }
      setTeamReservation(normalized)
      setTeamCode(String(normalized.parentId))
      setTeamLookup(null)
      setTeamLookupMessage('')
      openTeamConfirmation({
        id: normalized.parentId,
        parentId: normalized.parentId,
        name: normalized.parentName,
        parentName: normalized.parentName,
      }, 'boost')
      setTeamBoostMessage('Encontramos uma afiliada mãe para você.')
    } catch (e) {
      setTeamBoostMessage(e.message || 'Não foi possível encontrar uma equipe agora.')
    } finally {
      setTeamBoostBusy(false)
    }
  }

  const purchaseBoost = async (plan) => {
    setTeamBoostBusy(true)
    setTeamBoostMessage('')
    try {
      await api('/api/affiliate/dashboard', { method: 'POST', body: JSON.stringify({ action: 'boost_purchase', plan }) })
      setTeamBoostMessage('Impulso contratado. Seu saldo foi reservado e sua posição na fila foi registrada.')
      const [refreshed, boostData] = await Promise.all([api(`/api/affiliate/dashboard?month=${encodeURIComponent(selectedMonth || 'all')}`), api('/api/affiliate/dashboard?boost=1')])
      setDashboard(refreshed)
      setTeamBoost(boostData)
      return true
    } catch (e) {
      setTeamBoostMessage(e.message || 'Não foi possível contratar o impulso.')
      return false
    } finally {
      setTeamBoostBusy(false)
    }
  }

  const leaveBoostQueue = async () => {
    setTeamBoostBusy(true)
    setTeamBoostMessage('')
    try {
      await api('/api/affiliate/dashboard', { method: 'POST', body: JSON.stringify({ action: 'boost_leave_queue' }) })
      setTeamBoostMessage('Você saiu da fila e o valor foi devolvido ao seu saldo.')
      const [refreshed, boostData] = await Promise.all([api(`/api/affiliate/dashboard?month=${encodeURIComponent(selectedMonth || 'all')}`), api('/api/affiliate/dashboard?boost=1')])
      setDashboard(refreshed)
      setTeamBoost(boostData)
    } catch (e) {
      setTeamBoostMessage(e.message || 'Não foi possível sair da fila.')
    } finally {
      setTeamBoostBusy(false)
    }
  }

  const requestTeamWithdraw = async (event) => {
    event.preventDefault()
    setTeamWithdrawBusy(true)
    setTeamWithdrawMessage('')
    try {
      const amount = Number(String(teamWithdrawAmount).replace(',', '.'))
      await api('/api/affiliate/withdraw', {
        method: 'POST',
        body: JSON.stringify({ amount, source: 'team' }),
      })
      setTeamWithdrawAmount('')
      setTeamWithdrawMessage(`Solicitação de saque de equipe enviada. ${brl(amount)} ficou reservado para análise.`)
      const refreshed = await api(`/api/affiliate/dashboard?month=${encodeURIComponent(selectedMonth || 'all')}`)
      setDashboard(refreshed)
    } catch (e) {
      setTeamWithdrawMessage(e.message || 'Não foi possível solicitar o saque de equipe.')
    } finally {
      setTeamWithdrawBusy(false)
    }
  }

  const submitVideo = async () => {
    setVideoBusy(true)
    setVideoMessage('')
    try {
      await api('/api/affiliate/dashboard', {
        method: 'POST',
        body: JSON.stringify({ action: 'submit_video', videoUrl: videoUrl.trim(), termsAccepted: true, termsVersion: '1.0' }),
      })
      setVideoUrl('')
      setVideoTermsAccepted(false)
      setVideoTermsOpen(false)
      setVideoMessage('Link enviado. Sua solicitação está pendente de análise pela SHE.')
      const refreshed = await api('/api/affiliate/dashboard?videos=1')
      setVideoSubmissions(refreshed.videos || [])
    } catch (e) {
      setVideoMessage(e.message || 'Não foi possível enviar o link.')
    } finally {
      setVideoBusy(false)
    }
  }

  const savePix = async (event) => {
    event.preventDefault()
    setPixBusy(true)
    setPixMessage('')
    try {
      const result = await api('/api/affiliate/withdraw', {
        method: 'PATCH',
        body: JSON.stringify({ pixKey: pixKey.trim(), pixKeyType }),
      })
      const saved = result.pixKey || pixKey.trim()
      setPixKey(saved)
      setAffiliate(current => current ? { ...current, pix_key: saved, pix_key_type: pixKeyType } : current)
      setPixOpen(false)
      setPixMessage('PIX de recebimento salvo. Se você cadastrar outro, ele substituirá o atual para os próximos saques.')
    } catch (e) {
      setPixMessage(e.message || 'Não foi possível salvar o PIX.')
    } finally {
      setPixBusy(false)
    }
  }

  const cards = useMemo(() => {
    const m = dashboard?.metrics || {}
    return [
      ['Acessos', m.accesses || 0],
      ['Vendas', m.sales || 0],
      ['Ticket médio', brl(m.averageTicket)],
      ['Comissão', brl(m.commission)],
    ]
  }, [dashboard])

  if (loading) return <main className="min-h-screen bg-[#fffafc]" />

  if (!affiliate && isAdminPreview && !loading) {
    return <main className="min-h-screen bg-[#fffafc] p-8"><div className="mx-auto max-w-2xl rounded-2xl border border-amber-200 bg-amber-50 p-6 text-amber-950"><strong>Modo de Administrador - Cuidado</strong><p className="mt-2 text-sm">Não foi possível carregar o painel. Verifique se sua sessão administrativa está ativa.</p></div></main>
  }

  if (!affiliate) {
    return (
      <main className="min-h-screen bg-[#fffafc] flex items-center justify-center px-5 py-10">
        <div className="w-full max-w-md rounded-[2rem] bg-white p-8 shadow-[0_30px_100px_rgba(0,0,0,.10)] border border-pink-100">
          <div className="text-center">
            <p className="text-xs font-bold tracking-[.28em] text-pink-500 uppercase">She</p>
            <h1 className="mt-2 text-3xl font-black text-zinc-950">Área da afiliada</h1>
            <p className="mt-2 text-sm text-zinc-500">{registerMode ? 'Crie seu perfil e seu link exclusivo.' : 'Entre para acompanhar seus resultados.'}</p>
          </div>

          {!registerMode ? (
            <form onSubmit={submitLogin} className="mt-7 space-y-3">
              <input value={login.email} onChange={e => setLogin({...login,email:e.target.value})} type="email" autoComplete="username" required placeholder="E-mail" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 outline-none focus:border-pink-400" />
              <div className="relative">
                <input value={login.password} onChange={e => setLogin({...login,password:e.target.value})} type={showLoginPassword ? 'text' : 'password'} autoComplete="current-password" required placeholder="Senha" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 pr-12 outline-none focus:border-pink-400" />
                <button type="button" onClick={() => setShowLoginPassword(value => !value)} aria-label={showLoginPassword ? 'Ocultar senha' : 'Mostrar senha'} className="absolute inset-y-0 right-3 flex items-center text-zinc-400 hover:text-pink-500">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-5 w-5"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>{showLoginPassword && <path d="M3 3l18 18"/>}</svg>
                </button>
              </div>
              <label className="flex cursor-pointer items-center gap-2 px-1 text-sm text-zinc-600"><input type="checkbox" checked={rememberLogin} onChange={e => { const checked = e.target.checked; setRememberLogin(checked); if (!checked) { localStorage.removeItem('she_affiliate_saved_email'); localStorage.removeItem('she_affiliate_remember_login') } else { localStorage.setItem('she_affiliate_remember_login', 'true'); if (login.email) localStorage.setItem('she_affiliate_saved_email', login.email) } }} className="h-4 w-4 accent-pink-500" /><span>Salvar dados de login</span></label>
              {error && <p className="text-xs text-red-500">{error}</p>}
              <button disabled={busy} className="w-full rounded-2xl bg-pink-500 py-3.5 font-bold text-white disabled:opacity-60">{busy ? 'Entrando…' : 'Entrar'}</button>
              <button type="button" onClick={() => { setForgotOpen(v => !v); setForgotEmail(''); setForgotMessage('') }} className="mx-auto flex items-center justify-center pt-1 text-xs font-semibold text-zinc-400 transition-colors hover:text-zinc-600">
                Esqueceu sua senha? Receba um link por e-mail
              </button>

              {forgotOpen && (
                <div className="rounded-2xl border border-pink-100 bg-pink-50/70 p-4">
                  <p className="text-sm font-black text-zinc-900">Redefinir senha</p>
                  <p className="mt-1 text-xs leading-5 text-zinc-500">Digite o e-mail cadastrado na sua conta e enviaremos um link seguro para criar uma nova senha.</p>
                  <div className="mt-3 space-y-2">
                    <input value={forgotEmail} onChange={e => setForgotEmail(e.target.value)} type="email" required placeholder="Seu e-mail" className="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-pink-400" />
                    <button type="button" onClick={submitForgotPassword} disabled={forgotBusy} className="w-full rounded-xl bg-zinc-950 py-2.5 text-sm font-black text-white disabled:opacity-60">{forgotBusy ? 'Enviando…' : 'Enviar link por e-mail'}</button>
                  </div>
                  {forgotMessage && <p className="mt-2 text-xs leading-5 text-zinc-500">{forgotMessage}</p>}
                </div>
              )}
            </form>
          ) : (
            <form onSubmit={submitRegister} className="mt-7 space-y-3">
              <input value={form.name} onChange={e => setForm({...form,name:e.target.value.slice(0, 20)})} required maxLength={20} autoComplete="given-name" placeholder="Primeiro Nome" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 outline-none focus:border-pink-400" />
              <input value={registerSurname} onChange={e => setRegisterSurname(e.target.value.slice(0, 80))} maxLength={80} autoComplete="family-name" placeholder="Sobrenome" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 outline-none focus:border-pink-400" />
              <input value={form.whatsapp} onChange={e => setForm({...form,whatsapp:e.target.value})} type="tel" required placeholder="WhatsApp (31) 99999-9999" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 outline-none focus:border-pink-400" />
              <input value={form.cpf} onChange={e => setForm({...form,cpf:e.target.value})} inputMode="numeric" maxLength={14} required placeholder="CPF" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 outline-none focus:border-pink-400" />
              <input value={form.email} onChange={e => setForm({...form,email:e.target.value})} type="email" required placeholder="E-mail" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 outline-none focus:border-pink-400" />
              <div className="relative">
                <input value={form.password} onChange={e => setForm({...form,password:e.target.value})} type={showRegisterPassword ? 'text' : 'password'} autoComplete="new-password" minLength={8} required placeholder="Senha (mín. 8 caracteres)" className="w-full rounded-2xl border border-zinc-200 px-4 py-3 pr-12 outline-none focus:border-pink-400" />
                <button type="button" onClick={() => setShowRegisterPassword(value => !value)} aria-label={showRegisterPassword ? 'Ocultar senha' : 'Mostrar senha'} className="absolute inset-y-0 right-3 flex items-center text-zinc-400 hover:text-pink-500">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-5 w-5"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>{showRegisterPassword && <path d="M3 3l18 18"/>}</svg>
                </button>
              </div>
              {error && <p className="text-xs text-red-500">{error}</p>}
              <button type="submit" disabled={busy} className="w-full rounded-2xl bg-pink-500 py-3.5 font-bold text-white disabled:opacity-60">Criar conta</button>

              {registerTermsCardOpen && (
                <div className="fixed inset-0 z-[75] flex items-center justify-center bg-zinc-950/55 px-4 py-6 backdrop-blur-sm">
                  <div role="dialog" aria-modal="true" aria-labelledby="register-terms-title" className="w-full max-w-lg rounded-[2rem] border border-pink-100 bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.28)] sm:p-8">
                  <div className="mb-4 text-center"><span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-pink-100 text-pink-500"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6"><path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13h7M9 17h7"/></svg></span><p id="register-terms-title" className="mt-3 text-lg font-black text-zinc-900">Termos e Condições</p></div>
                  <p className="text-sm leading-6 text-zinc-600">Antes de criar sua conta, leia e aceite os Termos e Condições do programa de afiliadas.</p>
                  <div className="mt-4 flex flex-col gap-3">
                    <button type="button" onClick={() => setRegisterTermsOpen(true)} className="w-full rounded-xl border border-pink-200 bg-white px-4 py-3 text-sm font-black text-pink-600">Ler Termos e Condições</button>
                    <button type="button" disabled={busy} onClick={acceptRegisterTermsAndCreate} className="w-full rounded-xl bg-pink-500 px-4 py-3 text-sm font-black text-white shadow-lg shadow-pink-100 disabled:opacity-50">{busy ? 'Criando…' : '✓ Aceitar e cadastrar'}</button>
                    <button type="button" disabled={busy} onClick={() => setRegisterTermsCardOpen(false)} className="w-full py-1 text-sm font-semibold text-zinc-400">Voltar ao cadastro</button>
                  </div>
                  </div>
                </div>
              )}
            </form>
          )}

          <button type="button" onClick={() => { setRegisterMode(v => !v); setError(''); setRegisterTermsCardOpen(false); setRegisterTermsOpen(false) }} className="mt-4 w-full text-sm font-bold text-pink-500">
            {registerMode ? 'Já tenho uma conta' : 'Quero ser afiliada'}
          </button>

          {registerTermsOpen && (
            <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 px-5 py-8" onMouseDown={event => { if (event.target === event.currentTarget) setRegisterTermsOpen(false) }}>
              <div role="dialog" aria-modal="true" className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-[2rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.3)]">
                <div className="flex items-start justify-between gap-4">
                  <div><p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Termos e Condições</p><h3 className="mt-1 text-2xl font-black text-zinc-950">Programa de Afiliadas SHE</h3></div>
                  <button type="button" onClick={() => setRegisterTermsOpen(false)} className="h-9 w-9 rounded-full bg-zinc-100 text-zinc-500">×</button>
                </div>
                <div className="mt-5 space-y-4 text-sm leading-6 text-zinc-600">
                  <p><strong>1. Natureza da relação.</strong> O programa de afiliadas é uma relação comercial independente para divulgação de produtos e geração de vendas. A afiliada atua por sua própria conta e risco, sem salário, jornada, controle de ponto, subordinação, exclusividade ou garantia de remuneração mínima.</p>
                  <p><strong>2. Autonomia.</strong> A afiliada organiza livremente seus horários, métodos, canais e rotina de divulgação, podendo exercer outras atividades e trabalhar com outras empresas, desde que respeite a legislação e estes termos.</p>
                  <p><strong>3. Comissões.</strong> Os valores pagos decorrem exclusivamente de vendas elegíveis atribuídas ao link da afiliada e das regras comerciais vigentes. Comissão não constitui salário, ajuda de custo, benefício ou remuneração por disponibilidade.</p>
                  <p><strong>4. Ausência de garantia.</strong> A SHE não garante quantidade de vendas, faturamento, comissão ou renda. Resultados dependem das vendas efetivamente realizadas e validadas.</p>
                  <p><strong>5. Custos e obrigações.</strong> A afiliada é responsável por seus próprios equipamentos, internet, produção de conteúdo, publicidade, tributos e demais custos relacionados à sua atividade, salvo quando a SHE expressamente assumir determinado custo.</p>
                  <p><strong>6. Saques.</strong> Solicitações de saque estão sujeitas à conferência e processamento e podem levar <strong>até 3 dias</strong>. O prazo pode ser afetado por informações incorretas, inconsistências, fraude ou indisponibilidade de meios de pagamento.</p>
                  <p><strong>7. Conteúdo e publicidade.</strong> A afiliada deve divulgar os produtos de forma verdadeira, responsável e compatível com as orientações da SHE, sem prometer resultados garantidos, fazer alegações não autorizadas ou utilizar conteúdo que viole direitos de terceiros.</p>
                  <p><strong>8. Sistema de equipes.</strong> O sistema de equipes <strong>não é um sistema de pirâmide financeira</strong>. Não há cobrança para recrutar pessoas nem pagamento simplesmente pelo recrutamento. A equipe é apenas um mecanismo de incentivo comercial destinado a recompensar a afiliada mãe pelo suporte, treinamento e orientação que voluntariamente oferece às afiliadas de sua equipe. A afiliada mãe não é empregadora, chefe ou supervisora das demais afiliadas.</p>
                  <p><strong>9. Conduta.</strong> É proibido manipular vendas, utilizar fraude, autoindicação indevida, pedidos fictícios, spam, informações falsas, práticas enganosas ou qualquer conduta destinada a gerar comissão de maneira irregular. A SHE poderá suspender ou encerrar contas que violem estas regras.</p>
                  <p><strong>10. Reestruturação e alterações do plano de bonificação.</strong> A afiliada declara estar ciente e aceitar que, em caso de reestruturação do programa, a SHE poderá alterar, substituir ou reorganizar os planos de bonificação, critérios de elegibilidade, valores de comissão e regras de cálculo. As alterações poderão influenciar os critérios e valores de cálculo das comissões, bem como o saldo atual e futuro da afiliada. A SHE comunicará qualquer alteração na estrutura com antecedência mínima de 30 (trinta) dias corridos, por aviso na plataforma e/ou pelos canais de contato cadastrados. Durante esse prazo, a afiliada poderá se programar e solicitar as movimentações de saldo disponíveis que desejar realizar antes da entrada em vigor das mudanças. Ao término do prazo informado, as novas regras poderão ser aplicadas conforme a reestruturação comunicada, inclusive com impacto na apuração das comissões e na composição, disponibilidade e movimentação do saldo existente e futuro, observada a legislação aplicável.</p>
                  <p><strong>11. Lei e direitos legais.</strong> Estes termos descrevem a natureza pretendida da relação comercial e não têm por objetivo afastar direitos que não possam ser renunciados por lei. A realidade da relação entre as partes deverá permanecer compatível com a autonomia aqui descrita.</p>
                </div>
                <div className="mt-6 flex justify-end"><button type="button" onClick={() => setRegisterTermsOpen(false)} className="rounded-xl bg-zinc-950 px-5 py-3 text-sm font-black text-white">Fechar</button></div>
              </div>
            </div>
          )}
        </div>
      </main>
    )
  }

  const chart = dashboard?.chart || []
  const maxSales = Math.max(1, ...chart.map(x => Number(x.sales || 0)))
  // Reserva espaço vertical para o rótulo acima da maior barra, mantendo a escala proporcional.
  const chartScaleMax = maxSales * 1.25
  const chartBarAreaHeight = 88

  const hasAffiliateLink = Boolean(affiliate.slug)
  const publicUrl = hasAffiliateLink ? `https://shecoisademulher.com/${affiliate.slug}` : ''
  const qrUrl = publicUrl ? `https://quickchart.io/qr?size=220&text=${encodeURIComponent(publicUrl)}` : ''
  const config = dashboard?.settings || { ticketThreshold: 170, ticketBonus: 5, teamCommissionPerSale: 10, commissions: { none: 30, bronze: 40, silver: 50, gold: 60 } }
  const level = dashboard?.monthlyLevel || dashboard?.level || { key: 'none', label: 'Início', sales: 0, commissionPerOrder: Number(config.commissions?.none || 30), progress: 0, nextLevel: 'Bronze', nextMinSales: config.monthlyLevels?.bronze || 10, salesToNext: config.monthlyLevels?.bronze || 10 }
  const monthlyLevel = dashboard?.monthlyLevel || level
  const fixedLevel = dashboard?.fixedLevel || { key: 'none', label: 'Início', sales: Number(dashboard?.lifetimeSales || 0), progress: 0 }
  const months = dashboard?.months?.length ? dashboard.months : []
  const fixedProgress = fixedLevel.progress || 0
  const availableCommission = Number(dashboard?.metrics?.availableCommission || 0)
  const currentMonthPersonalSales = Number(dashboard?.metrics?.currentMonthPersonalSales || 0)
  const canWithdrawThisMonth = currentMonthPersonalSales >= 1
  const team = dashboard?.team || { code: affiliate.team_code || '', joined: false, canJoin: false, commissionPerSale: 10, earnedCommission: 0, availableCommission: 0, members: [], parent: null }
  const teamAdvanced1 = config.teamAdvanced1 || { members: 10, sales: 20, commissionPerSale: 15 }
  const teamAdvanced2 = config.teamAdvanced2 || { members: 20, sales: 40, commissionPerSale: 20 }
  const teamActiveMembers = Number(team.monthlyMembers || 0)
  const teamMonthSales = Number(team.monthlySales || 0)
  const teamHasAdvanced1 = teamActiveMembers >= Number(teamAdvanced1.members) && teamMonthSales >= Number(teamAdvanced1.sales)
  const teamHasAdvanced2 = teamActiveMembers >= Number(teamAdvanced2.members) && teamMonthSales >= Number(teamAdvanced2.sales)
  const teamMemberTarget = teamActiveMembers >= Number(teamAdvanced1.members) ? Number(teamAdvanced2.members) : Number(teamAdvanced1.members)
  const teamSalesTarget = teamMonthSales >= Number(teamAdvanced1.sales) ? Number(teamAdvanced2.sales) : Number(teamAdvanced1.sales)
  const teamMemberTargetLabel = teamActiveMembers >= Number(teamAdvanced1.members) ? 'para Equipe Avançada II' : 'para Equipe Avançada I'
  const teamSalesTargetLabel = teamMonthSales >= Number(teamAdvanced1.sales) ? 'para Equipe Avançada II' : 'para Equipe Avançada I'
  const teamBonusExpiresAt = dashboard?.teamBonus?.active && dashboard?.teamBonus?.expiresAt
    ? new Date(dashboard.teamBonus.expiresAt).getTime()
    : null
  const teamBonusRemainingDays = Number.isFinite(teamBonusExpiresAt) && teamBonusExpiresAt > Date.now()
    ? Math.ceil((teamBonusExpiresAt - Date.now()) / (24 * 60 * 60 * 1000))
    : 0
  const normalizedTeamSearch = teamSearch.trim().toLocaleLowerCase('pt-BR')
  const filteredTeamMembers = (team.members || []).filter(member =>
    String(member.name || '').toLocaleLowerCase('pt-BR').includes(normalizedTeamSearch) ||
    String(member.id ?? '').toLocaleLowerCase('pt-BR').includes(normalizedTeamSearch)
  )

  return (
    <main className="min-h-screen bg-[#fffafc] px-5 pb-8 pt-24 md:px-10 md:pt-28">
      {isAdminPreview && <div className="sticky top-0 z-[120] -mx-5 -mt-8 mb-6 flex flex-wrap items-center justify-between gap-3 border-b-2 border-amber-500 bg-amber-100 px-5 py-3 text-sm font-black text-amber-950 shadow-md md:-mx-10 md:px-10"><button type="button" onClick={() => { window.close(); if (window.history.length > 1) window.history.back(); else window.location.assign('/admin') }} className="inline-flex items-center gap-2 rounded-lg border border-amber-700/30 bg-white/70 px-3 py-2 font-black transition hover:bg-white"><span aria-hidden="true">←</span> Voltar ao painel admin</button><span className="text-center">⚠️ Modo de Administrador - Cuidado · Visualização de {affiliate?.name || 'afiliada'} · Ações que alteram dados estão bloqueadas</span><span className="hidden w-[150px] md:block" aria-hidden="true" /></div>}
      {pushPromptOpen && <div className="fixed inset-0 z-[110] flex items-center justify-center overflow-y-auto bg-zinc-950/60 p-4" role="dialog" aria-modal="true" aria-labelledby="push-prompt-title">
        <div className="my-auto w-full max-w-md overflow-hidden rounded-[2rem] border border-pink-100 bg-white shadow-2xl">
          <div className="bg-gradient-to-br from-pink-500 via-rose-400 to-fuchsia-500 px-6 pb-7 pt-8 text-center text-white"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-white/40 bg-white/20 text-3xl shadow-lg">🔔</div><p className="mt-4 text-[10px] font-black uppercase tracking-[.25em] text-white/80">She Afiliadas</p><h2 id="push-prompt-title" className="mt-2 text-2xl font-black">Não perca as novidades da sua equipe</h2><p className="mt-2 text-sm leading-6 text-white/90">Ative as notificações para receber avisos importantes diretamente no seu iPhone.</p></div>
          <div className="space-y-3 p-5 sm:p-6"><div className="flex gap-3 rounded-2xl bg-pink-50 p-3"><span className="text-xl">🏆</span><p className="text-xs leading-5 text-zinc-700"><strong>Conquistas e classificação</strong><br/>Saiba quando sua equipe alcançar novas metas.</p></div><div className="flex gap-3 rounded-2xl bg-pink-50 p-3"><span className="text-xl">💗</span><p className="text-xs leading-5 text-zinc-700"><strong>Novidades importantes</strong><br/>Receba atualizações relevantes do programa de afiliadas.</p></div>{pushMessage && <p className="rounded-xl bg-amber-50 p-3 text-xs leading-5 text-amber-800">{pushMessage}</p>}<button type="button" disabled={pushBusy} onClick={enablePushNotifications} className="w-full rounded-xl bg-pink-600 px-4 py-3.5 text-sm font-black text-white shadow-lg shadow-pink-200 disabled:opacity-60">{pushBusy ? 'Ativando…' : 'Ativar notificações'}</button><button type="button" onClick={dismissPushPrompt} className="w-full rounded-xl px-4 py-2.5 text-xs font-bold text-zinc-500 hover:bg-zinc-50">Agora não</button><p className="text-center text-[10px] leading-4 text-zinc-400">Você controla essa permissão nas configurações do iPhone.</p></div>
        </div>
      </div>}
      {installHelpOpen && <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-zinc-950/55 p-4" role="dialog" aria-modal="true" aria-labelledby="install-help-title">
        <div className="my-auto w-full max-w-lg rounded-[2rem] border border-pink-100 bg-white p-5 shadow-2xl sm:p-7">
          <div className="flex items-start gap-3">
            <img src="/pwa-icon-192.png" alt="Ícone do app She Afiliadas" className="h-16 w-16 rounded-2xl shadow-sm" />
            <div className="min-w-0 flex-1"><p className="text-[10px] font-black uppercase tracking-[.22em] text-pink-500">She Afiliadas</p><h2 id="install-help-title" className="mt-1 text-xl font-black text-zinc-950">{isAndroidDevice ? 'Instale o app oficial She Afiliadas' : 'Adicione a She à tela inicial'}</h2><p className="mt-1 text-sm leading-5 text-zinc-500">{isAndroidDevice ? 'Um aplicativo exclusivo para as afiliadas da SHE.' : 'Acesse seu painel como um aplicativo, direto pelo ícone da She.'}</p></div>
            <button type="button" onClick={() => setInstallHelpOpen(false)} aria-label="Fechar" className="rounded-full p-2 text-xl leading-none text-zinc-400 hover:bg-zinc-100">×</button>
          </div>
          {isIosDevice && !isSafariBrowser ? <div className="mt-5 space-y-4">
            <div className="rounded-2xl border border-pink-100 bg-[#fff7fb] p-5 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-3xl shadow-sm">🧭</div>
              <h3 className="mt-3 text-lg font-black text-zinc-950">Baixe o app pelo Safari.</h3>
              <p className="mt-2 text-sm leading-6 text-zinc-600">Para adicionar a She à tela inicial do iPhone, abra este site no Safari e toque em “Baixar App”.</p>
            </div>
          </div> : isIosDevice ? <div className="mt-5 space-y-3">
            <div className="flex gap-3 rounded-2xl border border-zinc-100 bg-[#fffafc] p-3.5"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-2xl font-black shadow-sm">···</div><div><p className="text-sm font-extrabold text-zinc-900">1. Toque nos três pontinhos (···)</p><p className="mt-1 text-xs leading-5 text-zinc-600">No Safari do iPhone, toque no menu de três pontinhos na parte inferior da tela para abrir as opções da página.</p><div className="mt-2 inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-[11px] font-bold text-zinc-500 shadow-sm"><span className="text-lg">···</span> Menu do Safari</div></div></div>
            <div className="flex gap-3 rounded-2xl border border-zinc-100 bg-[#fffafc] p-3.5"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-2xl shadow-sm">↥</div><div><p className="text-sm font-extrabold text-zinc-900">2. Toque em “Compartilhar”</p><p className="mt-1 text-xs leading-5 text-zinc-600">No menu que abrir, escolha Compartilhar (ícone de um quadrado com uma seta para cima), se essa opção aparecer.</p><div className="mt-2 inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-[11px] font-bold text-zinc-500 shadow-sm"><span className="text-lg text-sky-600">□↑</span> Compartilhar</div></div></div>
            <div className="flex gap-3 rounded-2xl border border-zinc-100 bg-[#fffafc] p-3.5"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-2xl shadow-sm">⌄</div><div><p className="text-sm font-extrabold text-zinc-900">3. Toque na setinha de “Ver Mais”</p><p className="mt-1 text-xs leading-5 text-zinc-600">Na tela de Compartilhar, toque na seta para baixo ao lado de “Ver Mais” para expandir a lista completa de opções.</p><div className="mt-2 inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-[11px] font-bold text-zinc-600 shadow-sm"><span className="text-lg">Ver Mais⌄</span> Mostrar opções</div></div></div>
            <div className="flex gap-3 rounded-2xl border border-zinc-100 bg-[#fffafc] p-3.5"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-2xl shadow-sm">＋</div><div><p className="text-sm font-extrabold text-zinc-900">4. Escolha “Adicionar à Tela de Início”</p><p className="mt-1 text-xs leading-5 text-zinc-600">Depois de expandir “Ver Mais”, procure e toque em “Adicionar à Tela de Início”.</p><div className="mt-2 inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-[11px] font-bold text-zinc-600 shadow-sm"><span className="flex h-5 w-5 items-center justify-center rounded-md bg-pink-100 text-pink-600">＋</span> Adicionar à Tela de Início</div></div></div>
            <div className="flex gap-3 rounded-2xl border border-pink-100 bg-pink-50/70 p-3.5"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-2xl shadow-sm">✓</div><div><p className="text-sm font-extrabold text-zinc-900">5. Confirme em “Adicionar”</p><p className="mt-1 text-xs leading-5 text-zinc-600">O ícone oficial da She Afiliadas aparecerá na tela inicial do iPhone. Na próxima vez, abra por esse ícone.</p></div></div>
            <p className="rounded-xl bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-800">Importante: no iPhone, faça isso pelo Safari. Outros navegadores podem não mostrar a mesma opção.</p>
          </div> : isAndroidDevice ? <div className="mt-5 space-y-3">
            <div className="rounded-2xl border border-pink-100 bg-[#fff7fb] p-4"><p className="text-sm font-extrabold text-zinc-900">Por que o app não está na Play Store?</p><p className="mt-1 text-sm leading-6 text-zinc-600">O She Afiliadas é um aplicativo individual, disponibilizado diretamente pela SHE para suas afiliadas. Ele não é distribuído pela Google Play Store; por isso, como acontece com aplicativos que o Google ainda não conhece ou verificou, o Play Protect pode mostrar um alerta de segurança durante a instalação.</p></div>
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4"><p className="text-sm font-extrabold text-amber-950">Se aparecer o aviso do Play Protect</p><ol className="mt-2 list-decimal space-y-2 pl-5 text-sm leading-6 text-amber-950"><li>Toque na setinha para baixo para expandir os detalhes do aviso, se essa opção aparecer.</li><li>Procure e toque em <strong>“Instalar mesmo assim”</strong>, caso essa opção seja exibida pelo Android.</li></ol><p className="mt-2 text-xs leading-5 text-amber-900">Só prossiga se você iniciou o download por este painel oficial da SHE e reconhece o aplicativo. Um aviso pode ocorrer por o app não ser conhecido pelo Google, mas não é possível concluir apenas pelo aviso que todo arquivo é seguro.</p></div>
            <div className="rounded-2xl bg-zinc-50 p-4"><p className="text-sm font-extrabold text-zinc-900">Aplicativo oficial da SHE</p><p className="mt-1 text-sm leading-6 text-zinc-600">Este é o APK disponibilizado pela SHE para acesso ao painel de afiliadas. Mantenha o arquivo e o link de download restritos a fontes oficiais.</p></div>
            <button type="button" onClick={() => { setInstallHelpOpen(false); window.location.href = '/she-afiliadas.apk' }} className="w-full rounded-xl bg-pink-600 px-4 py-3.5 text-sm font-black text-white shadow-lg shadow-pink-200 hover:bg-pink-700">Baixar app oficial para Android</button>
          </div> : <div className="mt-5 space-y-3"><div className="rounded-2xl bg-[#fffafc] p-4"><p className="text-sm font-extrabold text-zinc-900">Instale a She no seu dispositivo</p><p className="mt-1 text-sm leading-6 text-zinc-600">Use a opção de instalação do navegador. Se ela não aparecer, abra o menu do navegador e procure “Instalar app” ou “Adicionar à tela inicial”.</p></div>{installPrompt && <button type="button" onClick={handleInstallApp} className="w-full rounded-xl bg-pink-600 px-4 py-3 text-sm font-black text-white hover:bg-pink-700">Instalar agora</button>}</div>}
          <button type="button" onClick={() => setInstallHelpOpen(false)} className="mt-5 w-full rounded-xl bg-zinc-950 px-4 py-3 text-sm font-black text-white transition hover:bg-zinc-800">Entendi</button>
        </div>
      </div>}
      <header className="fixed inset-x-0 top-2 z-[80] px-3 sm:top-3 sm:px-4">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 rounded-2xl border border-white/50 bg-white/45 px-4 py-2 shadow-[0_8px_30px_rgba(30,10,20,.10)] ring-1 ring-pink-100/30 backdrop-blur-2xl md:px-6">
          <div aria-label="She Afiliadas" className="shrink-0 select-none text-sm font-black tracking-tight text-zinc-950 md:text-base">SHE<span className="text-pink-500">.</span><span className="ml-1.5 text-[10px] font-bold text-zinc-400 md:text-xs">AFILIADAS</span></div>
          <div className="flex min-w-0 flex-wrap items-center justify-end gap-1.5 md:gap-2">
            <div className="relative">
              <button type="button" aria-haspopup="menu" aria-expanded={affiliateNavOpen} onClick={() => setAffiliateNavOpen(open => !open)} className="inline-flex items-center gap-1.5 rounded-lg border border-pink-200 bg-white px-3 py-2 text-[11px] font-black text-pink-700 shadow-sm transition hover:bg-pink-50 md:text-xs">
                Menu <span aria-hidden="true" className={`transition-transform ${affiliateNavOpen ? 'rotate-180' : ''}`}>⌄</span>
              </button>
              {affiliateNavOpen && <>
                <button type="button" aria-label="Fechar menu" className="fixed inset-0 z-40 cursor-default" onClick={() => setAffiliateNavOpen(false)} />
                <div role="menu" className="absolute right-0 top-full z-50 mt-2 w-52 overflow-hidden rounded-2xl border border-pink-100 bg-white p-2 shadow-[0_16px_45px_rgba(30,10,20,.18)]">
                  {[
                    ['award', 'Qualificação', 'qualificacao'],
                    ['chart', 'Desempenho', 'desempenho'],
                    ['wallet', 'Saque', 'saque'],
                    ['link', 'Meu Link', 'meu-link'],
                    ['team', 'Equipe', 'equipe'],
                    ['video', 'Divulgar Vídeo', 'divulgar-video'],
                    ['shop', 'Loja de Afiliadas', 'loja-afiliadas'],
                  ].map(([icon, label, sectionId]) => <button key={sectionId} type="button" role="menuitem" onClick={() => scrollToAffiliateSection(sectionId)} className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-xs font-bold text-zinc-700 transition hover:bg-pink-50 hover:text-pink-700 focus:bg-pink-50 focus:outline-none"><span aria-hidden="true" className="flex h-4 w-4 shrink-0 items-center justify-center text-pink-500">
                    {icon === 'award' ? <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M8 4h8l2 4-6 5-6-5 2-4Z"/><path d="m6 13-1 7 7-3 7 3-1-7M8 4l4 9 4-9"/></svg>
                    : icon === 'chart' ? <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M4 19V5M4 19h17"/><rect x="7" y="12" width="3" height="5" rx="1"/><rect x="12" y="8" width="3" height="9" rx="1"/><rect x="17" y="4" width="3" height="13" rx="1"/></svg>
                    : icon === 'wallet' ? <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7"><rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 9V6a3 3 0 0 1 3-3h12M15 13h6"/><circle cx="15" cy="13" r="1"/></svg>
                    : icon === 'link' ? <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M10 13a5 5 0 0 0 7 .2l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7-.2l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>
                    : icon === 'team' ? <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2M16 5a3 3 0 0 1 0 6M18 14a5 5 0 0 1 3 5v1"/></svg>
                    : icon === 'video' ? <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7"><rect x="3" y="5" width="13" height="14" rx="3"/><path d="m16 10 5-3v10l-5-3z"/><path d="m8 9 4 3-4 3z" fill="currentColor" stroke="none"/></svg>
                    : <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M3 9h18l-2-5H5L3 9Z"/><path d="M5 9v11h14V9M9 20v-7h6v7"/></svg>}
                  </span><span>{label}</span></button>)}
                  <div className="my-1 h-px bg-pink-100"/>
                </div>
              </>}
            </div>
            <button type="button" onClick={() => load({ sync: true })} disabled={syncing} className="rounded-lg bg-pink-500 px-3 py-2 text-[11px] font-black text-white shadow-sm transition hover:bg-pink-600 disabled:opacity-60 md:text-xs">{syncing ? 'Atualizando…' : 'Atualizar'}</button>
            {hasAffiliateLink && <Link to={`/${affiliate.slug}`} className="hidden rounded-lg border border-zinc-200 bg-white px-3 py-2 text-[11px] font-black text-zinc-700 sm:inline-flex">Ver página</Link>}
          </div>
        </div>
      </header>
      <div className="mx-auto max-w-7xl">
        <div className="mb-2 border-b border-pink-100/80 pb-4">
          <h1 className="text-2xl font-black text-zinc-950 md:text-3xl">Olá, {affiliate.name}.</h1>
          <p className="mt-1 text-xs text-zinc-500">{selectedMonth === 'all' ? 'Indicadores acumulados de todo o período' : `Indicadores de ${monthLabel(selectedMonth)}`}</p>
          {syncMessage && <p className="mt-1 text-[11px] font-semibold text-zinc-400">{syncMessage}</p>}
        </div>
        {!hasAffiliateLink && (
          <section className="relative mt-7 overflow-hidden rounded-[2rem] border-2 border-pink-200 bg-white p-6 shadow-[0_0_35px_rgba(236,72,153,.28)] md:p-8">
            <div className="absolute -inset-1 -z-10 rounded-[2rem] bg-pink-300/20 blur-2xl" />
            <p className="text-[10px] font-black uppercase tracking-[.22em] text-pink-500">Primeiro passo</p>
            <h2 className="mt-2 text-2xl font-black text-zinc-950">Crie seu link de afiliada</h2>
            <p className="mt-2 text-sm leading-6 text-zinc-500">Escolha o nome que você quer usar no seu link. Seu ID já foi criado e será acrescentado automaticamente.</p>
            <form onSubmit={createAffiliateLink} className="mt-5">
              <div className="flex overflow-hidden rounded-2xl border-2 border-pink-100 bg-white focus-within:border-pink-400">
                <input value={linkSlug} onChange={e => setLinkSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 40))} required placeholder="Ex.: ana" className="min-w-0 flex-1 px-4 py-4 text-base font-bold outline-none" />
                <span className="flex items-center bg-zinc-100 px-4 text-sm font-black text-zinc-400">ID {affiliate.id}</span>
              </div>
              <p className="mt-2 px-1 text-xs font-semibold text-zinc-400">Seu link: <span className="text-zinc-500">shecoisademulher.com/{linkSlug || 'ana'}{affiliate.id}</span></p>
              {linkMessage && <p className="mt-3 rounded-xl bg-zinc-50 px-3 py-2 text-xs font-semibold text-zinc-600">{linkMessage}</p>}
              <button disabled={linkBusy || !linkSlug.trim()} className="mt-4 w-full rounded-2xl bg-pink-500 py-4 font-black text-white shadow-lg shadow-pink-200 transition hover:bg-pink-600 disabled:cursor-not-allowed disabled:opacity-50">{linkBusy ? 'Criando seu link…' : 'Criar meu link'}</button>
            </form>
          </section>
        )}

        <div className={!hasAffiliateLink ? 'pointer-events-none select-none grayscale opacity-40' : ''}>
        {!isStandaloneApp && !isAdminPreview && <div className="mb-3 mt-4 flex justify-start">
          <button type="button" onClick={handleInstallApp} className="rounded-lg border border-pink-200 bg-white/80 px-4 py-2 text-xs font-black text-pink-700 shadow-sm transition hover:bg-pink-50" aria-label="Baixar App">
            Baixar App
          </button>
        </div>}

        {!team.joined && Number(dashboard?.lifetimeSales || 0) === 0 && (
          <section className="mt-7 rounded-[1.5rem] border border-pink-100 bg-white p-5 shadow-sm md:p-6">
            {team.joined ? (
              <div>
                <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Sua afiliada mãe</p>
                <div className="mt-2 flex items-center gap-3">
                  <div>
                    <p className="text-lg font-black text-zinc-950">{team.parent?.name || 'Afiliada mãe'}</p>
                    <p className="mt-1 text-xs text-zinc-400">Sua equipe é definida e não pode ser alterada.</p>
                  </div>
                </div>
              </div>
            ) : team.canJoin && (
              <>
                <p className="text-[10px] font-black uppercase tracking-[.2em] text-zinc-400">Equipe</p>
                <h2 className="mt-1 text-xl font-black text-zinc-950">Entre em uma equipe</h2>
                <p className="mt-1 text-xs leading-5 text-zinc-500">Entre em uma equipe e qualifique como bronze por 30 dias corridos.</p>
                <p className="mt-1 text-xs leading-5 text-zinc-400">Digite o ID de quem indicou você ou encontre uma afiliada mãe disponível. Antes de entrar, você poderá conferir os dados e aceitar as condições do vínculo.</p>
                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  <form onSubmit={joinTeam} className="flex min-w-0 flex-1 gap-2">
                    <input value={teamCode} onChange={e => { setTeamCode(e.target.value.replace(/\D/g, '').slice(0, 12)); setTeamLookup(null); setTeamLookupMessage(''); setTeamJoinMessage('') }} disabled={teamJoinBusy || Boolean(teamReservation)} inputMode="numeric" placeholder="ID da afiliada mãe" className="min-w-0 flex-1 rounded-xl border border-zinc-200 px-3 py-2.5 text-sm font-bold outline-none focus:border-pink-400" />
                    <button disabled={teamJoinBusy || teamLookupBusy || !teamCode || !teamLookup || Number(teamLookup.id) !== Number(teamCode)} className="rounded-xl bg-zinc-950 px-4 py-2.5 text-sm font-black text-white disabled:cursor-not-allowed disabled:opacity-40">Revisar e entrar</button>
                  </form>
                  <button type="button" onClick={findTeam} disabled={teamBoostBusy || Boolean(teamReservation)} className="rounded-xl border border-pink-200 bg-pink-50 px-4 py-2.5 text-sm font-black text-pink-600 disabled:cursor-not-allowed disabled:opacity-40">{teamBoostBusy ? 'Buscando…' : 'Encontrar uma equipe'}</button>
                </div>
                {teamCode && !teamReservation && (
                  <div className={`mt-3 rounded-xl border px-3 py-2.5 text-xs ${teamLookup ? 'border-pink-200 bg-pink-50 text-zinc-700' : 'border-zinc-100 bg-zinc-50 text-zinc-500'}`} aria-live="polite">
                    {teamLookupBusy ? 'Buscando afiliada pelo ID…' : teamLookup ? <>Sua afiliada mãe será: <strong className="text-zinc-950">{teamLookup.name}</strong> <span className="text-zinc-400">(ID {teamLookup.id})</span></> : teamLookupMessage || 'Digite o ID para localizar a afiliada mãe.'}
                  </div>
                )}
                {teamReservation && !teamConfirmOpen && <div className="mt-3 flex flex-col gap-2 rounded-xl border border-pink-100 bg-pink-50 px-3 py-3 sm:flex-row sm:items-center sm:justify-between"><p className="text-xs font-semibold text-zinc-700">Sua afiliada mãe será: <strong>{teamReservation.parentName}</strong></p><button type="button" onClick={() => openTeamConfirmation({ id: teamReservation.parentId, parentId: teamReservation.parentId, name: teamReservation.parentName, parentName: teamReservation.parentName }, 'boost')} className="rounded-lg bg-pink-500 px-3 py-2 text-xs font-black text-white">Revisar seleção</button></div>}
                {teamJoinMessage && <p className="mt-2 text-xs font-semibold text-zinc-500">{teamJoinMessage}</p>}
                {teamBoostMessage && <p className="mt-2 text-xs font-semibold text-zinc-500">{teamBoostMessage}</p>}
              </>
            )}
          </section>
        )}

        <section id="qualificacao" style={{ scrollMarginTop: 82 }} className={`relative mt-7 overflow-hidden rounded-[2rem] border border-white bg-gradient-to-r ${levelTone(level.key)} p-5 shadow-sm md:p-7`}>
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[.2em] text-zinc-400">Qualificação Mensal</p>
              <div className="mt-1 flex flex-wrap items-baseline gap-3">
                <h2 className={`text-3xl font-black ${levelAccent(level.key)}`}>{level.label}</h2>
                <span className="text-sm font-bold text-zinc-600">{monthlyLevel.sales} vendas pessoais + equipe</span>
                <span className="rounded-full bg-white/80 px-3 py-1 text-sm font-black text-zinc-800">{brl(level.commissionPerOrder)} / pedido</span>
              </div>
              <p className="mt-2 text-sm text-zinc-500">
                {monthlyLevel.nextLevel
                  ? `Faltam ${monthlyLevel.salesToNext} venda(s) para ${monthlyLevel.nextLevel}.`
                  : 'Você atingiu o nível máximo deste mês.'}
              </p>
              {dashboard?.teamBonus?.active && teamBonusRemainingDays > 0 && (
                <p className="mt-2 inline-flex max-w-full items-center rounded-md border border-pink-100 bg-pink-50 px-2 py-1 text-[11px] font-semibold leading-4 text-pink-700">
                  Bônus de equipe ativo. {teamBonusRemainingDays === 1 ? 'Resta 1 dia' : `Restam ${teamBonusRemainingDays} dias`} para o término do bônus.
                </p>
              )}
            </div>
            <div className="min-w-[220px] text-right">
              <p className="text-xs font-bold text-zinc-400">PROGRESSO</p>
              <p className="mt-1 text-2xl font-black text-zinc-900">{Math.round(Math.max(monthlyLevel.progress, level.progress))}%</p>
            </div>
          </div>

          <div className="relative mx-auto mt-8 h-[92px] w-[82%] max-w-[520px] px-0">
            <div className="absolute left-0 right-0 top-4 h-4 overflow-hidden rounded-full bg-zinc-200/80">
              <div className="absolute inset-y-0 left-0 bg-zinc-400 transition-all duration-700" style={{ width: `${Math.min(100, Math.max(0, Math.min(Math.max(monthlyLevel.progress, level.progress), 10)))}%` }} />
              <div className="absolute inset-y-0 left-[10%] bg-orange-400 transition-all duration-700" style={{ width: `${Math.max(0, Math.min(40, Math.max(monthlyLevel.progress, level.progress) - 10))}%` }} />
              <div className="absolute inset-y-0 left-[50%] bg-zinc-500 transition-all duration-700" style={{ width: `${Math.max(0, Math.min(40, Math.max(monthlyLevel.progress, level.progress) - 50))}%` }} />
              <div className="absolute inset-y-0 left-[90%] bg-amber-400 transition-all duration-700" style={{ width: `${Math.max(0, Math.min(10, Math.max(monthlyLevel.progress, level.progress) - 90))}%` }} />
            </div>


            {[
              { label: 'Bronze', min: Number(config.monthlyLevels?.bronze || 10), image: '/badge-bronze.svg', rate: brl(dashboard?.monthlyCommissionRates?.bronze ?? config.commissions?.bronze), tone: 'text-[#9a5a22]' },
              { label: 'Prata', min: Number(config.monthlyLevels?.silver || 50), image: '/badge-silver.svg', rate: brl(dashboard?.monthlyCommissionRates?.silver ?? config.commissions?.silver), tone: 'text-zinc-500' },
              { label: 'Ouro', min: Number(config.monthlyLevels?.gold || 101), image: '/badge-gold.svg', rate: brl(dashboard?.monthlyCommissionRates?.gold ?? config.commissions?.gold), tone: 'text-amber-600' },
            ].map(item => {
              const markerLeft = item.label === 'Bronze' ? '10%' : item.label === 'Prata' ? '50%' : '90%'
              return (
                <div key={item.label} className="absolute top-0 -translate-x-1/2 text-center" style={{ left: markerLeft }}>
                  <div className="mx-auto h-10 w-10 rounded-full border-2 border-white bg-white shadow-[0_5px_14px_rgba(0,0,0,.14)] sm:h-12 sm:w-12">
                    <img src={item.image} alt={`Broche ${item.label}`} className="h-full w-full object-contain" />
                  </div>
                  <div className={`mt-1 whitespace-nowrap text-[11px] font-black leading-none sm:text-xs ${item.tone}`}>{item.rate}<span className="ml-0.5 text-[8px] font-bold sm:text-[9px]">/pedido</span></div>
                  <div className="mt-1 text-[8px] font-black uppercase tracking-wider text-zinc-400 sm:text-[9px]">{item.label}</div>
                  <div className="mt-1 whitespace-nowrap text-[8px] font-black text-zinc-500 sm:text-[9px]">{item.min} vendas</div>
                </div>
              )
            })}
          </div>
          <button type="button" aria-label="Como funcionam os níveis" onClick={() => setLevelHelpOpen(true)} className="absolute bottom-4 right-5 flex h-6 w-6 items-center justify-center rounded-full border border-zinc-200 bg-white/90 text-xs font-black text-zinc-500 shadow-sm transition hover:border-pink-300 hover:text-pink-500">?</button>
        </section>

        <section className={`relative mt-5 overflow-hidden rounded-[2rem] border border-white bg-gradient-to-r ${levelTone(fixedLevel.key)} p-5 shadow-sm md:p-7`}>
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[.2em] text-zinc-400">Qualificação Permanente</p>
              <div className="mt-1 flex flex-wrap items-baseline gap-3">
                <h2 className={`text-3xl font-black ${levelAccent(fixedLevel.key)}`}>{fixedLevel.label}</h2>
                <span className="text-sm font-bold text-zinc-600">{fixedLevel.sales} vendas pessoais</span>
              </div>
              <p className="mt-2 text-sm text-zinc-500">
                {fixedLevel.nextLevel ? `Faltam ${fixedLevel.salesToNext} venda(s) pessoal(is) para ${fixedLevel.nextLevel}.` : 'Você atingiu a qualificação permanente máxima.'}
              </p>
            </div>
            <div className="min-w-[220px] text-right">
              <p className="text-xs font-bold text-zinc-400">PROGRESSO ACUMULADO</p>
              <p className="mt-1 text-2xl font-black text-zinc-900">{Math.round(fixedProgress)}%</p>
            </div>
          </div>
          <div className="relative mx-auto mt-8 h-[92px] w-[82%] max-w-[520px] px-0">
            <div className="absolute left-0 right-0 top-4 h-4 overflow-hidden rounded-full bg-zinc-200/80">
              <div className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-zinc-400 via-orange-400 via-zinc-500 to-amber-400 transition-all duration-700" style={{ width: `${Math.min(100, fixedProgress)}%` }} />
            </div>
            {[
              { label: 'Bronze', min: Number(config.fixedLevels?.bronze || 50), image: '/badge-bronze.svg', tone: 'text-[#9a5a22]' },
              { label: 'Prata', min: Number(config.fixedLevels?.silver || 300), image: '/badge-silver.svg', tone: 'text-zinc-500' },
              { label: 'Ouro', min: Number(config.fixedLevels?.gold || 500), image: '/badge-gold.svg', tone: 'text-amber-600' },
            ].map(item => {
              const fixedMax = Number(config.fixedLevels?.gold || 500)
              const markerLeft = `${Math.min(100, Math.max(0, item.min / Math.max(1, fixedMax) * 100))}%`
              return <div key={item.label} className="absolute top-0 -translate-x-1/2 text-center" style={{ left: markerLeft }}>
                <div className="mx-auto h-10 w-10 rounded-full border-2 border-white bg-white shadow-[0_5px_14px_rgba(0,0,0,.14)] sm:h-12 sm:w-12"><img src={item.image} alt={`Broche ${item.label}`} className="h-full w-full object-contain" /></div>
                <div className={`mt-1 whitespace-nowrap text-[8px] font-black uppercase tracking-wider sm:text-[9px] ${item.tone}`}>{item.label}</div>
                <div className="mt-1 text-[8px] font-black text-zinc-400 sm:text-[9px]">{item.min} vendas</div>
              </div>
            })}
          </div>
          <button type="button" aria-label="Como funciona a Qualificação Permanente" onClick={() => setFixedHelpOpen(true)} className="absolute bottom-4 right-5 flex h-6 w-6 items-center justify-center rounded-full border border-zinc-200 bg-white/90 text-xs font-black text-zinc-500 shadow-sm transition hover:border-pink-300 hover:text-pink-500">?</button>
        </section>

        <div className="mt-7 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-end">
          <div className="w-full sm:w-64">
            <label htmlFor="affiliate-month-filter" className="mb-2 block text-[10px] font-black uppercase tracking-[.16em] text-zinc-400">Filtrar indicadores por mês</label>
            <select id="affiliate-month-filter" value={selectedMonth} onChange={event => changeSelectedMonth(event.target.value)} className="w-full rounded-xl border border-pink-100 bg-white px-4 py-3 text-sm font-bold text-zinc-800 outline-none focus:border-pink-400">
              <option value="all">Todos os meses</option>
              {[...months].sort((a, b) => b.localeCompare(a)).map(month => <option key={month} value={month}>{monthLabel(month)}</option>)}
            </select>
          </div>
        </div>

        <section className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map(([label, value]) => {
            const multiplierActive = label === 'Ticket médio' && dashboard?.metrics?.ticketMultiplierActive
            return (
              <div key={label} className={`relative rounded-[1.5rem] p-5 border shadow-sm transition-all ${multiplierActive ? 'border-amber-300 bg-gradient-to-br from-amber-100 via-yellow-50 to-white shadow-[0_0_35px_rgba(245,158,11,.28)]' : 'border-pink-100 bg-white'}`}>
                <p className={`text-xs uppercase tracking-[.18em] ${multiplierActive ? 'text-amber-700' : 'text-zinc-400'}`}>{label}</p>
                <p className={`mt-3 text-2xl font-black ${multiplierActive ? 'text-amber-900' : 'text-zinc-950'}`}>{value}</p>
                {multiplierActive && <span className="mt-2 inline-flex rounded-full bg-amber-400/20 px-2.5 py-1 text-[11px] font-black text-amber-800">+ {brl(dashboard?.metrics?.ticketMultiplierValue ?? config.ticketBonus)} / pedido</span>}
                {label === 'Ticket médio' && <p className={`mt-2 text-[10px] leading-4 ${multiplierActive ? 'text-amber-700' : 'text-zinc-400'}`}>Ticket médio deste período acima de {brl(dashboard?.metrics?.ticketMultiplierThreshold ?? config.ticketThreshold)} ativa + {brl(dashboard?.metrics?.ticketMultiplierValue ?? config.ticketBonus)} por pedido.</p>}
              </div>
            )
          })}
        </section>

        <section id="desempenho" style={{ scrollMarginTop: 82 }} className="mt-6 grid min-w-0 grid-cols-1 items-start gap-6 lg:grid-cols-2">
          <div className="order-1 self-start w-full min-w-0 rounded-[1.5rem] bg-white p-5 border border-pink-100 shadow-sm lg:col-start-1 lg:row-start-1">
            <div className="flex items-end justify-between gap-4">
              <div>
                <h2 className="font-black text-xl">Desempenho mensal</h2>
                <p className="mt-1 text-sm text-zinc-400">Quantidade de vendas em cada mês. O mês atual continua acumulando até fechar.</p>
              </div>
              <div className="hidden sm:block text-right text-xs text-zinc-400">Evolução mês a mês</div>
            </div>

            <div ref={chartScrollRef} className="mt-4 h-[155px] w-full overflow-x-auto overflow-y-hidden rounded-xl bg-white pb-2 overscroll-x-contain scroll-smooth">
              <div className="h-[135px] min-w-[520px] px-1">
                <div className="flex h-[118px] items-end gap-1 border-b border-zinc-100 pt-[22px]">
                  {chart.map((item) => {
                    const sales = Number(item.sales || 0)
                    const height = sales ? Math.max(8, (sales / chartScaleMax) * chartBarAreaHeight) : 3
                    return (
                      <div key={item.date} data-chart-index={chart.indexOf(item)} className="group flex h-full min-w-[72px] flex-1 flex-col justify-end">
                        <div className="relative flex flex-1 items-end justify-center">
                          {sales > 0 && <span className="absolute left-1/2 -translate-x-1/2 whitespace-nowrap text-[8px] font-black text-zinc-700" style={{ bottom: `${height + 5}px` }}>{sales}</span>}
                          <div title={`${item.label || monthLabel(item.date)} — ${sales} venda(s)`} className="w-[18px] rounded-t-md bg-pink-400 transition-all duration-300 group-hover:bg-pink-500" style={{ height: `${height}px`, minHeight: sales ? undefined : '3px' }} />
                        </div>
                        <span className="mt-2 text-center text-[8px] font-bold text-zinc-400">{item.label || monthLabel(item.date)}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
            <p className="mt-1 text-center text-[10px] text-zinc-400 sm:hidden">Deslize para ver os meses anteriores</p>
          </div>

          <div id="saque" style={{ scrollMarginTop: 82 }} className="order-2 rounded-[1.5rem] bg-white p-6 border border-pink-100 shadow-sm lg:col-start-2 lg:row-start-1">
              <h2 className="font-black text-xl">Saldo e saque pessoal</h2>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-zinc-100 bg-zinc-50 p-4">
                  <p className="text-[10px] font-black uppercase tracking-[.14em] text-zinc-400">Comissão total acumulada</p>
                  <p className="mt-1 text-xl font-black text-zinc-950">{brl(dashboard?.metrics?.totalCommission ?? dashboard?.metrics?.earnedCommission ?? 0)}</p>
                  <p className="mt-1 text-[11px] text-zinc-400">Todos os meses, sem descontar movimentações</p>
                </div>
                <div className="rounded-2xl border border-pink-100 bg-pink-50/70 p-4">
                  <p className="text-[10px] font-black uppercase tracking-[.14em] text-pink-500">Saldo disponível</p>
                  <p className="mt-1 text-xl font-black text-zinc-950">{brl(availableCommission)}</p>
                  <p className="mt-1 text-[11px] text-zinc-500">Após reservas de saques e impulsos</p>
                </div>
              </div>
              <form onSubmit={requestWithdraw} className="mt-5">
                <input
                  value={withdrawAmount}
                  onChange={e => setWithdrawAmount(e.target.value)}
                  inputMode="decimal"
                  placeholder="Ex.: 100"
                  className="w-full rounded-2xl border border-zinc-200 px-4 py-3.5 text-lg font-bold outline-none focus:border-pink-400"
                />
                <button disabled={withdrawBusy || !canWithdrawThisMonth} className="mt-3 w-full rounded-2xl bg-zinc-950 py-4 text-base font-black text-white transition hover:bg-pink-500 disabled:cursor-not-allowed disabled:bg-zinc-300 disabled:text-zinc-500 disabled:opacity-100">
                  {withdrawBusy ? 'Enviando…' : 'Solicitar saque'}
                </button>
              </form>
              <p className="mt-3 text-xs leading-5 text-zinc-400">Saque mínimo de R$ 100,00. Os pedidos devem ser feitos em múltiplos de R$ 100,00. Para liberar o saque, é necessário ter pelo menos 1 venda pessoal contabilizada neste mês.</p>
              {withdrawMessage && <p className="mt-3 rounded-xl bg-zinc-50 px-3 py-2 text-xs font-semibold text-zinc-600">{withdrawMessage}</p>}
          </div>

          <div className="order-3 rounded-[1.5rem] bg-white p-6 border border-pink-100 shadow-sm lg:col-start-1 lg:row-start-2">
              <h2 className="font-black text-xl">PIX de recebimento</h2>
              <p className="mt-2 text-sm text-zinc-500">Cadastre a chave PIX onde você quer receber seus saques.</p>
              {pixKey ? (
                <div className="mt-4 rounded-2xl bg-zinc-50 px-4 py-3">
                  <p className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">PIX cadastrado</p>
                  <p className="mt-1 break-all text-sm font-bold text-zinc-900">{pixKey}</p>
                </div>
              ) : (
                <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs font-semibold leading-5 text-amber-800">
                  Cadastre seu PIX antes de solicitar um saque.
                </div>
              )}
              <button
                type="button"
                onClick={() => { setPixOpen(value => !value); setPixMessage('') }}
                className="mt-3 w-full rounded-2xl bg-pink-500 py-3.5 font-black text-white transition hover:bg-pink-600"
              >
                {pixOpen ? 'Fechar' : (pixKey ? 'Alterar PIX de recebimento' : 'Cadastrar PIX de recebimento')}
              </button>
              {pixOpen && (
                <form onSubmit={savePix} className="mt-4 border-t border-zinc-100 pt-4">
                  <label className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">Tipo da chave PIX</label>
                  <select
                    value={pixKeyType}
                    onChange={e => setPixKeyType(e.target.value)}
                    className="mt-2 w-full rounded-2xl border border-zinc-200 bg-white px-4 py-3.5 text-sm font-bold outline-none focus:border-pink-400"
                  >
                    <option value="CPF">CPF</option>
                    <option value="CNPJ">CNPJ</option>
                    <option value="EMAIL">E-mail</option>
                    <option value="PHONE">Telefone</option>
                    <option value="EVP">Chave aleatória</option>
                  </select>
                  <label className="mt-3 block text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">Nova chave PIX</label>
                  <input
                    value={pixKey}
                    onChange={e => setPixKey(e.target.value)}
                    required
                    maxLength={255}
                    autoComplete="off"
                    placeholder="CPF, CNPJ, e-mail, telefone ou chave aleatória"
                    className="mt-2 w-full rounded-2xl border border-zinc-200 px-4 py-3.5 text-sm outline-none focus:border-pink-400"
                  />
                  <button disabled={pixBusy} className="mt-3 w-full rounded-2xl bg-zinc-950 py-3.5 font-black text-white disabled:opacity-60">
                    {pixBusy ? 'Salvando…' : 'Salvar PIX'}
                  </button>
                </form>
              )}
              {pixMessage && <p className="mt-3 rounded-xl bg-zinc-50 px-3 py-2 text-xs font-semibold leading-5 text-zinc-600">{pixMessage}</p>}
          </div>

          <div id="meu-link" style={{ scrollMarginTop: 82 }} className="order-4 rounded-[1.5rem] bg-white p-6 border border-pink-100 shadow-sm lg:col-start-2 lg:row-start-2">
              <h2 className="font-black text-xl">Seu link</h2>
              <p className="mt-2 text-sm text-zinc-500">Compartilhe sua página exclusiva.</p>
              <div className="mt-5 rounded-xl bg-zinc-50 p-4 text-sm font-semibold break-all">{publicUrl}</div>
              <button onClick={() => navigator.clipboard?.writeText(publicUrl)} className="mt-3 w-full rounded-xl bg-pink-500 py-3 font-bold text-white">Copiar link</button>
              <img src={qrUrl} alt="QR Code da afiliada" className="mx-auto mt-5 h-44 w-44 rounded-xl border border-zinc-100 p-2" />
          </div>
        </section>

        <section id="equipe" style={{ scrollMarginTop: 82 }} className="mt-6 rounded-[1.5rem] border border-pink-100 bg-white p-6 shadow-sm">
          {team.joined && team.parent && (
            <div className="mb-5 rounded-2xl border border-pink-100 bg-pink-50/60 p-4">
              <p className="text-[10px] font-black uppercase tracking-[.18em] text-pink-500">Sua afiliada mãe</p>
              <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
                <p className="text-lg font-black text-zinc-950">{team.parent.name}</p>
                {team.parent.whatsapp && (() => {
                  const parentWhatsApp = String(team.parent.whatsapp).replace(/\D/g, '')
                  const whatsappNumber = parentWhatsApp.startsWith('55') ? parentWhatsApp : `55${parentWhatsApp}`
                  return <a href={`https://wa.me/${whatsappNumber}`} target="_blank" rel="noreferrer" aria-label={`Conversar com ${team.parent.name} pelo WhatsApp`} className="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-4 py-2.5 text-sm font-black text-white shadow-sm transition hover:bg-emerald-600"><svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5" fill="currentColor"><path d="M20.52 3.48A11.86 11.86 0 0 0 12.08 0C5.47 0 .1 5.37.1 11.98c0 2.11.55 4.17 1.6 5.99L0 24l6.2-1.63a11.94 11.94 0 0 0 5.88 1.5h.01c6.61 0 11.98-5.37 11.98-11.98 0-3.2-1.25-6.2-3.55-8.41ZM12.09 21.8a9.9 9.9 0 0 1-5.04-1.38l-.36-.21-3.68.97.98-3.59-.23-.37a9.83 9.83 0 0 1-1.51-5.24c0-5.44 4.43-9.87 9.88-9.87a9.8 9.8 0 0 1 6.98 2.89 9.8 9.8 0 0 1 2.89 6.99c0 5.44-4.43 9.87-9.89 9.87Zm5.42-7.39c-.3-.15-1.77-.87-2.05-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.47-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.49s1.07 2.89 1.22 3.09c.15.2 2.1 3.21 5.09 4.5.71.31 1.27.49 1.7.63.71.23 1.36.2 1.87.12.57-.08 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35Z"/></svg>WhatsApp</a>
                })()}
              </div>
            </div>
          )}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Equipe</p>
              <h2 className="mt-1 text-2xl font-black text-zinc-950">Sua rede</h2>
              <p className="mt-1 text-sm text-zinc-500">Passe seu ID para novas afiliadas entrarem diretamente na sua equipe.</p>
              <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-pink-50 px-4 py-2"><span className="text-xs font-bold text-zinc-500">Seu ID</span><span className="text-lg font-black tracking-[.08em] text-pink-600">{affiliate.id}</span></div>
            </div>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-pink-100 bg-white px-4 py-3 shadow-sm"><p className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">Afiliadas totais na equipe</p><p className="mt-1 text-2xl font-black text-zinc-950">{(team.members || []).length}</p><p className="mt-1 text-xs text-zinc-500">Total de afiliadas diretas cadastradas na sua rede.</p></div>
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50/60 px-4 py-3 shadow-sm"><p className="text-[10px] font-black uppercase tracking-[.15em] text-emerald-700">Afiliadas ativas neste mês</p><p className="mt-1 text-2xl font-black text-zinc-950">{teamActiveMembers}</p><p className="mt-1 text-xs text-zinc-500">Afiliadas diretas com pelo menos 1 venda aprovada neste mês.</p></div>
          </div>

          <div className="mt-5 overflow-hidden rounded-[1.6rem] border border-pink-200 bg-gradient-to-br from-[#fff0f6] via-white to-[#fff7ed] shadow-sm">
            <div className="flex flex-col gap-4 border-b border-pink-100 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
              <div className="flex items-center gap-4">
                <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl shadow-sm ${teamHasAdvanced2 ? 'bg-gradient-to-br from-amber-300 to-yellow-500 text-white' : teamHasAdvanced1 ? 'bg-gradient-to-br from-fuchsia-500 to-pink-600 text-white' : 'bg-white text-pink-500 ring-1 ring-pink-100'}`}>
                  <svg viewBox="0 0 24 24" aria-hidden="true" className="h-7 w-7 fill-none stroke-current stroke-[1.8]"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3.5 14.6 8.8l5.9.9-4.25 4.15 1 5.85L12 16.9l-5.25 2.8 1-5.85L3.5 9.7l5.9-.9L12 3.5Z"/><path strokeLinecap="round" d="M8.8 11.8 11 14l4.4-4.5"/></svg>
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Sua classificação mensal</p>
                  <h3 className="mt-1 text-2xl font-black tracking-tight text-zinc-950 sm:text-3xl">{teamHasAdvanced2 ? 'Equipe Avançada II' : teamHasAdvanced1 ? 'Equipe Avançada I' : 'Equipe Base'}</h3>
                  <p className="mt-1 text-sm text-zinc-600">{teamHasAdvanced2 ? 'Você alcançou o nível máximo de equipe deste mês. Parabéns!' : teamHasAdvanced1 ? 'Meta Avançada I conquistada! Continue crescendo para chegar à Avançada II.' : 'Cada afiliada ativa e cada venda aproximam você do próximo nível.'}</p>
                </div>
              </div>
            </div>
            <div className="grid gap-4 p-5 sm:grid-cols-2 sm:p-6">
              <div className="rounded-2xl border border-white bg-white/90 p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3"><div><p className="text-xs font-black uppercase tracking-[.12em] text-zinc-500">Afiliadas ativas</p><p className="mt-1 text-2xl font-black text-zinc-950">{teamActiveMembers}/{teamMemberTarget}</p></div><span className="rounded-full bg-pink-50 px-3 py-1.5 text-[10px] font-black text-pink-600">{teamHasAdvanced2 ? 'Meta final' : teamMemberTargetLabel}</span></div>
                <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-pink-100"><div className="h-full rounded-full bg-gradient-to-r from-pink-400 to-fuchsia-600 transition-all duration-500" style={{ width: `${Math.min(100, teamMemberTarget > 0 ? teamActiveMembers / teamMemberTarget * 100 : 0)}%` }} /></div>
                <p className="mt-2 text-xs leading-5 text-zinc-500">Só contam afiliadas diretas com pelo menos 1 venda aprovada neste mês.</p>
              </div>
              <div className="rounded-2xl border border-white bg-white/90 p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3"><div><p className="text-xs font-black uppercase tracking-[.12em] text-zinc-500">Vendas de equipe</p><p className="mt-1 text-2xl font-black text-zinc-950">{teamMonthSales}/{teamSalesTarget}</p></div><span className="rounded-full bg-fuchsia-50 px-3 py-1.5 text-[10px] font-black text-fuchsia-700">{teamHasAdvanced2 ? 'Meta final' : teamSalesTargetLabel}</span></div>
                <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-fuchsia-100"><div className="h-full rounded-full bg-gradient-to-r from-fuchsia-500 to-pink-500 transition-all duration-500" style={{ width: `${Math.min(100, teamSalesTarget > 0 ? teamMonthSales / teamSalesTarget * 100 : 0)}%` }} /></div>
                <p className="mt-2 text-xs leading-5 text-zinc-500">A classificação considera as vendas aprovadas da equipe direta neste mês.</p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-2 border-t border-pink-100 bg-white/60 p-4 sm:grid-cols-3 sm:p-5">
              <div className={`rounded-xl px-3 py-3 ${!teamHasAdvanced1 ? 'bg-pink-100 ring-1 ring-pink-200' : 'bg-white'}`}><p className="text-xs font-black text-zinc-800">Equipe Base</p><p className="mt-1 text-sm font-bold text-pink-600">{brl(config.teamCommissionPerSale || 10)} por venda</p><p className="mt-1 text-[10px] text-zinc-500">Nível inicial</p></div>
              <div className={`rounded-xl px-3 py-3 ${teamHasAdvanced1 && !teamHasAdvanced2 ? 'bg-pink-100 ring-1 ring-pink-200' : 'bg-white'}`}><p className="text-xs font-black text-zinc-800">Equipe Avançada I</p><p className="mt-1 text-sm font-bold text-pink-600">{brl(teamAdvanced1.commissionPerSale)} por venda</p><p className="mt-1 text-[10px] text-zinc-500">Mín. {teamAdvanced1.sales} vendas equipe. Mín. {teamAdvanced1.members} afiliadas ativas</p></div>
              <div className={`rounded-xl px-3 py-3 ${teamHasAdvanced2 ? 'bg-amber-50 ring-1 ring-amber-200' : 'bg-white'}`}><p className="text-xs font-black text-zinc-800">Equipe Avançada II</p><p className="mt-1 text-sm font-bold text-pink-600">{brl(teamAdvanced2.commissionPerSale)} por venda</p><p className="mt-1 text-[10px] text-zinc-500">Mín. {teamAdvanced2.sales} vendas equipe. Mín. {teamAdvanced2.members} afiliadas ativas</p></div>
            </div>
          </div>

          <div className="mt-5">
            <label htmlFor="team-member-search" className="mb-2 block text-xs font-black uppercase tracking-[.12em] text-zinc-500">Pesquisar afiliada por nome ou ID</label>
            <input
              id="team-member-search"
              type="search"
              value={teamSearch}
              onChange={event => setTeamSearch(event.target.value)}
              placeholder="Digite o nome ou ID da afiliada..."
              className="w-full rounded-xl border border-zinc-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-pink-400 focus:ring-2 focus:ring-pink-100"
            />
          </div>
          <div className="mt-3 max-h-[320px] overflow-auto rounded-xl border border-zinc-100">
            <table className="w-full min-w-[520px] text-sm">
              <thead className="sticky top-0 z-10 bg-white"><tr className="border-b border-zinc-100 text-left text-[10px] font-black uppercase tracking-[.14em] text-zinc-400"><th className="pb-3">Afiliada</th><th className="pb-3">ID</th><th className="pb-3">Vendas</th><th className="pb-3">Comissão gerada</th></tr></thead>
              <tbody>{filteredTeamMembers.map(member => <tr key={member.id} className="border-b border-zinc-100 last:border-0"><td className="py-3 font-black"><div className="flex items-center gap-2"><a href={whatsappUrl(member.whatsapp) || '#'} target={member.whatsapp ? '_blank' : undefined} rel={member.whatsapp ? 'noreferrer' : undefined} aria-label={member.whatsapp ? `Falar com ${member.name} pelo WhatsApp` : undefined} className={member.whatsapp ? 'text-[#25D366] transition-opacity hover:opacity-70' : 'pointer-events-none text-zinc-200'}><svg aria-hidden="true" viewBox="0 0 24 24" className="h-4 w-4 fill-current"><path d="M20.52 3.48A11.82 11.82 0 0 0 12.08 0C5.55 0 .24 5.31.24 11.84c0 2.09.55 4.13 1.59 5.93L.13 24l6.38-1.67a11.8 11.8 0 0 0 5.57 1.42h.01c6.53 0 11.84-5.31 11.84-11.84 0-3.16-1.23-6.13-3.41-8.43ZM12.09 21.8h-.01a9.91 9.91 0 0 1-5.05-1.39l-.36-.21-3.79.99 1.01-3.69-.23-.38a9.9 9.9 0 0 1-1.52-5.28C2.14 6.37 6.6 1.91 12.08 1.91c2.65 0 5.14 1.03 7.01 2.9a9.86 9.86 0 0 1 2.91 7.02c0 5.48-4.46 9.94-9.91 9.97Zm5.44-7.45c-.3-.15-1.78-.88-2.05-.98-.27-.1-.47-.15-.67.15-.2.3-.77.98-.94 1.18-.17.2-.35.22-.65.07-.3-.15-1.27-.47-2.42-1.49-.9-.8-1.51-1.78-1.69-2.08-.18-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.61-.92-2.21-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.49s1.07 2.89 1.22 3.09c.15.2 2.11 3.22 5.12 4.52.72.31 1.28.5 1.72.64.72.23 1.37.2 1.89.12.58-.09 1.78-.73 2.03-1.44.25-.71.25-1.32.18-1.44-.07-.12-.27-.2-.57-.35Z"/></svg></a><div className="min-w-0"><span className="block">{member.name}</span><span className="mt-0.5 block text-[9px] font-black uppercase tracking-[.12em] text-zinc-400">{member.teamJoinSource === 'boost' ? 'Impulsionado' : 'Orgânico'}</span></div></div></td><td className="py-3 text-zinc-500">{member.id}</td><td className="py-3 font-bold">{member.sales}</td><td className="py-3 font-black text-pink-600">{brl(member.commission)}</td></tr>)}</tbody>
            </table>
            {!team.members?.length && <div className="py-6 text-center text-sm text-zinc-400">Nenhuma afiliada entrou na sua equipe ainda.</div>}
            {!!team.members?.length && !filteredTeamMembers.length && <div className="py-6 text-center text-sm text-zinc-400">Nenhuma afiliada encontrada para essa pesquisa.</div>}
          </div>



          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-zinc-100 bg-zinc-50 p-4"><p className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">Comissão gerada</p><p className="mt-1 text-2xl font-black text-zinc-950">{brl(team.earnedCommission)}</p></div>
            <div className="rounded-2xl border border-pink-100 bg-pink-50/60 p-4"><p className="text-[10px] font-black uppercase tracking-[.15em] text-pink-500">Saldo de Equipe</p><p className="mt-1 text-2xl font-black text-zinc-950">{brl(team.availableCommission)}</p></div>
          </div>

          <div className="mt-5 rounded-2xl border border-pink-100 bg-white p-4">
            <p className="text-sm font-black text-zinc-900">Sacar comissão de equipe</p>
            <p className="mt-1 text-xs text-zinc-400">Esse saldo é separado da sua bonificação pessoal. Saque mínimo de R$ 100,00, sempre em múltiplos de R$ 100,00. Para liberar o saque, é necessário ter pelo menos 1 venda pessoal contabilizada neste mês.</p>
            <form onSubmit={requestTeamWithdraw} className="mt-3 flex flex-col gap-2 sm:flex-row">
              <input value={teamWithdrawAmount} onChange={e => setTeamWithdrawAmount(e.target.value)} inputMode="decimal" placeholder="Ex.: 100" className="flex-1 rounded-xl border border-zinc-200 px-4 py-3 font-bold outline-none focus:border-pink-400" />
              <button disabled={teamWithdrawBusy || team.availableCommission < 100 || !canWithdrawThisMonth} className="rounded-xl bg-pink-500 px-5 py-3 font-black text-white disabled:cursor-not-allowed disabled:bg-zinc-300 disabled:text-zinc-500 disabled:opacity-100">{teamWithdrawBusy ? 'Enviando…' : 'Solicitar saque de equipe'}</button>
            </form>
            {teamWithdrawMessage && <p className="mt-2 rounded-xl bg-zinc-50 px-3 py-2 text-xs font-semibold text-zinc-600">{teamWithdrawMessage}</p>}
          </div>

        {hasAffiliateLink && (
          <section className="mt-5 rounded-[1.5rem] border border-pink-100 bg-white p-5 shadow-sm md:p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">🚀 Impulsionar Equipe</p>
                  <button type="button" onClick={() => setBoostHelpOpen(true)} aria-label="Como funciona o Impulsionar Equipe" className="flex h-5 w-5 items-center justify-center rounded-full border border-zinc-300 text-[11px] font-black text-zinc-500 transition hover:border-pink-300 hover:text-pink-500">?</button>
                </div>
                <h2 className="mt-1 text-xl font-black text-zinc-950">Receba novas afiliadas na sua equipe</h2>
                <p className="mt-1 text-xs leading-5 text-zinc-400">O sistema direciona novas afiliadas para você. Depois que o impulso for ativado, não há cancelamento nem reembolso. Enquanto estiver na fila, você pode sair e receber o saldo de volta.</p>
              </div>
              <div className="text-left lg:text-right"><p className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">Saldo disponível</p><p className="mt-1 text-xl font-black text-zinc-950">{brl(availableCommission)}</p></div>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {(teamBoost?.plans || [{ key:'small', price:30, connections:5 }, { key:'large', price:50, connections:10 }]).map(plan => {
                const insufficient = availableCommission + 0.001 < Number(plan.price)
                const blockedByActive = teamBoost?.boost?.status === 'queued' || teamBoost?.boost?.status === 'active'
                const capacityFull = Number(teamBoost?.activeCount || 0) >= Number(teamBoost?.maxActive || 3)
                const visuallyQueued = capacityFull || insufficient || blockedByActive
                return <div key={plan.key} className={`rounded-2xl border p-4 ${visuallyQueued ? 'border-zinc-200 bg-zinc-100/80 text-zinc-400' : 'border-pink-100 bg-pink-50/50'}`}>
                  <div className="flex items-start justify-between gap-3"><div><p className={`text-sm font-black ${visuallyQueued ? 'text-zinc-500' : 'text-zinc-950'}`}>{plan.connections} conexões</p><p className="mt-1 text-xs text-zinc-400">Impulsionamento automático</p></div><p className={`shrink-0 whitespace-nowrap text-lg font-black sm:text-xl ${visuallyQueued ? 'text-zinc-500' : 'text-pink-600'}`}>{brl(plan.price)}</p></div>
                  <button type="button" onClick={() => { setBoostConfirmPlan(plan); setBoostTermsAccepted(false) }} disabled={teamBoostBusy || insufficient || blockedByActive} className="mt-4 w-full rounded-xl bg-zinc-950 py-3 text-xs font-black text-white disabled:cursor-not-allowed disabled:bg-zinc-300">{blockedByActive ? (teamBoost?.boost?.status === 'queued' ? 'Já está na fila' : 'Impulso ativo') : insufficient ? 'Saldo insuficiente' : capacityFull ? 'Entrar na fila' : 'Impulsionar equipe'}</button>
                </div>
              })}
            </div>
            {teamBoost?.boost?.status === 'queued' && <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4"><p className="text-sm font-black text-amber-900">Você está na fila de impulsos.</p><p className="mt-1 text-xs leading-5 text-amber-800">Seu saldo está reservado. Quando chegar sua vez, o impulso será ativado automaticamente.</p><button type="button" onClick={leaveBoostQueue} disabled={teamBoostBusy} className="mt-3 rounded-xl bg-white px-4 py-2.5 text-xs font-black text-amber-800 shadow-sm">Sair da fila e devolver saldo</button></div>}
            {teamBoost?.boost?.status === 'active' && <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-4"><p className="text-sm font-black text-emerald-900">Impulso ativo</p><p className="mt-1 text-xs font-semibold text-emerald-800">{teamBoost.boost.connections_remaining} de {teamBoost.boost.connections_total} conexões restantes.</p></div>}
            {teamBoostMessage && <p className="mt-3 text-xs font-semibold text-zinc-500">{teamBoostMessage}</p>}
          </section>
        )}

        </section>


        <section id="divulgar-video" style={{ scrollMarginTop: 82 }} className="relative mt-6 rounded-[1.5rem] border border-pink-100 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Conteúdo</p>
              <h2 className="mt-1 text-2xl font-black text-zinc-950">Divulgue seu vídeo</h2>
            </div>
            <span className="rounded-full bg-pink-50 px-3 py-2 text-xs font-black text-pink-600">Envio para análise</span>
          </div>

          <form onSubmit={event => { event.preventDefault(); setVideoMessage(''); if (!videoUrl.trim()) { setVideoMessage('Informe o link do vídeo.'); return } setVideoTermsAccepted(false); setVideoTermsOpen(true) }} className="mt-5 flex flex-col gap-3 sm:flex-row">
            <input value={videoUrl} onChange={e => setVideoUrl(e.target.value)} type="url" placeholder="Cole aqui o link do vídeo publicado" className="min-w-0 flex-1 rounded-2xl border border-zinc-200 px-4 py-3.5 text-sm outline-none focus:border-pink-400" />
            <button disabled={videoBusy || !videoUrl.trim()} className="rounded-2xl bg-zinc-950 px-6 py-3.5 font-black text-white transition hover:bg-pink-500 disabled:cursor-not-allowed disabled:opacity-40">Enviar</button>
          </form>
          {videoMessage && <p className="mt-3 rounded-xl bg-zinc-50 px-3 py-2 text-xs font-semibold text-zinc-600">{videoMessage}</p>}

          <div className="mt-5 space-y-3">
            {videoSubmissions.map(item => (
              <div key={item.id} className="rounded-2xl border border-zinc-100 bg-zinc-50/70 p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0"><p className="text-xs font-black uppercase tracking-[.14em] text-zinc-400">Solicitação #{item.id}</p><p className="mt-1 truncate text-sm font-bold text-zinc-700">{item.video_url}</p><p className="mt-1 text-xs text-zinc-400">Enviado em {new Date(item.created_at).toLocaleDateString('pt-BR')}</p></div>
                  <span className={`shrink-0 rounded-full px-3 py-1.5 text-[11px] font-black ${item.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : item.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'}`}>{item.status === 'approved' ? 'Aprovado' : item.status === 'rejected' ? 'Rejeitado' : 'Pendente'}</span>
                </div>
                {item.note && <p className="mt-3 rounded-xl bg-white px-3 py-2 text-xs font-semibold leading-5 text-zinc-600"><strong>Observação da SHE:</strong> {item.note}</p>}
              </div>
            ))}
            {!videoSubmissions.length && <div className="rounded-2xl border border-dashed border-zinc-200 px-4 py-6 text-center text-sm text-zinc-400">Você ainda não enviou nenhum vídeo para análise.</div>}
          </div>
          <button type="button" aria-label="Como funciona a divulgação de vídeos" onClick={() => setVideoHelpOpen(true)} className="absolute bottom-4 right-5 flex h-6 w-6 items-center justify-center rounded-full border border-zinc-200 bg-white/90 text-xs font-black text-zinc-500 shadow-sm transition hover:border-pink-300 hover:text-pink-500">?</button>
        </section>

        <section className="mt-6 rounded-[1.5rem] bg-white p-6 border border-pink-100 overflow-x-auto shadow-sm">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="font-black text-xl">Pedidos atribuídos</h2>
              <p className="mt-1 text-sm text-zinc-400">Todos os pedidos aprovados</p>
            </div>
            <span className="rounded-full bg-pink-50 px-3 py-1 text-xs font-black text-pink-500">{dashboard?.metrics?.sales || 0} venda(s)</span>
          </div>
          <table className="mt-5 w-full min-w-[700px] text-sm">
            <thead><tr className="text-left text-xs uppercase tracking-wider text-zinc-400"><th className="pb-3">Pedido</th><th className="pb-3">Status</th><th className="pb-3">Valor</th><th className="pb-3">Comissão</th><th className="pb-3">Data</th></tr></thead>
            <tbody>
              {(dashboard?.orders || []).map(order => (
                <tr key={order.yampi_order_id} className="border-t border-zinc-100">
                  <td className="py-3 font-semibold">{order.yampi_order_id}</td>
                  <td className="py-3"><span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700">Pagamento aprovado</span></td>
                  <td className="py-3">{brl(order.total)}</td>
                  <td className="py-3 font-bold">{brl(order.commission)}</td>
                  <td className="py-3">{new Date(order.created_at).toLocaleDateString('pt-BR')}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!dashboard?.orders?.length && <div className="py-10 text-center text-sm text-zinc-400">Nenhuma venda aprovada ainda.</div>}
        </section>

        <section id="loja-afiliadas" style={{ scrollMarginTop: 82 }} className="mt-6 overflow-hidden rounded-[1.8rem] border border-pink-100 bg-gradient-to-br from-white via-pink-50 to-rose-100 p-5 shadow-sm md:p-7">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div><p className="text-[10px] font-black uppercase tracking-[.25em] text-pink-500">Benefícios She</p><h2 className="mt-1 text-2xl font-black text-zinc-950">Sua loja de benefícios</h2><p className="mt-1 max-w-xl text-sm text-zinc-600">Use suas comissões para adquirir os produtos She. Uma unidade de cada produto por mês.</p></div>
            <span className="rounded-full border border-pink-200 bg-white/80 px-3 py-1.5 text-xs font-bold text-pink-700">Pagamento com saldo</span>
          </div>
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            {[{key:'hydrant',name:'Hidratante Íntimo She',image:hidratanteProductImage,desc:'Cuidado íntimo premium',price:productShop.prices?.hydrant},{key:'stick',name:'Stick Clareador She',image:stickProductImage,desc:'Praticidade para sua rotina',price:productShop.prices?.stick}].map(product => {
              const now = new Date()
              const thisMonth = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`
              const boughtThisMonth = (productShop.purchases || []).some(p => p.product === product.key && !['rejected','cancelled'].includes(p.status) && String(p.created_at || '').slice(0,7) === thisMonth)
              const available = Number(dashboard?.metrics?.availableCommission || 0)
              return <div key={product.key} className="flex min-w-0 flex-col overflow-hidden rounded-2xl border border-white bg-white shadow-sm sm:flex-row">
                <div className="flex min-h-[180px] items-center justify-center bg-white p-3 sm:w-[42%]"><img src={product.image} alt={product.name} className="max-h-48 w-full object-contain" /></div>
                <div className="flex flex-1 flex-col p-4"><p className="text-[10px] font-black uppercase tracking-widest text-pink-500">Produto exclusivo</p><h3 className="mt-1 text-lg font-black text-zinc-950">{product.name}</h3><p className="mt-1 text-xs text-zinc-500">{product.desc}</p><p className="mt-4 text-2xl font-black text-zinc-950">{Number.isFinite(Number(product.price)) && Number(product.price) > 0 ? brl(product.price) : 'Preço indisponível'}</p><p className="mt-1 text-[11px] text-zinc-500">Saldo disponível: {brl(available)}</p>
                <button type="button" disabled={!Number.isFinite(Number(product.price)) || Number(product.price) <= 0 || boughtThisMonth || available < product.price} onClick={() => {setPurchaseProduct(product.key); setPurchaseMessage('')}} className="mt-4 rounded-xl bg-gradient-to-r from-pink-600 to-rose-500 px-4 py-3 text-xs font-black text-white shadow-sm transition hover:brightness-105 disabled:cursor-not-allowed disabled:bg-zinc-200 disabled:text-zinc-400">{!Number.isFinite(Number(product.price)) || Number(product.price) <= 0 ? 'Preço indisponível' : boughtThisMonth ? 'Já solicitado neste mês' : available < product.price ? 'Saldo insuficiente' : 'Adquirir com meu saldo'}</button>
                {boughtThisMonth && <p className="mt-2 text-[11px] text-amber-700">Você já solicitou este produto neste mês.</p>}</div>
              </div>
            })}
          </div>
          {(productShop.purchases || []).some(p => p.freight_paid !== true && !['rejected','cancelled'].includes(p.status)) && <div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 p-4"><h3 className="font-black text-amber-950">Pagamento do frete · R$ 16,00</h3><p className="mt-1 text-sm text-amber-900">O pagamento é feito pela Woovi, separado do saldo usado no produto. A confirmação é automática e libera a preparação do envio.</p><div className="mt-3 space-y-3">{productShop.purchases.filter(p => p.freight_paid !== true && !['rejected','cancelled'].includes(p.status)).map(p => <div key={`freight-${p.id}`} className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-white p-3"><div><p className="text-sm font-black text-zinc-900">Solicitação #{p.id} · {p.product === 'hydrant' ? 'Hidratante' : 'Stick'}</p><p className="mt-1 text-xs text-zinc-500">{p.freight_payment_url ? 'Aguardando confirmação do pagamento' : 'Link de pagamento ainda não disponível'}</p></div><div className="flex flex-wrap gap-2">{p.freight_payment_url && <a href={p.freight_payment_url} target="_blank" rel="noreferrer" className="rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-black text-white">Pagar frete · R$ 16</a>}{!p.freight_payment_url && <button type="button" disabled={purchaseBusy} onClick={() => createFreightPaymentLink(p.id)} className="rounded-xl bg-pink-600 px-4 py-2.5 text-xs font-black text-white disabled:opacity-50">{purchaseBusy ? 'Gerando…' : 'Gerar link de pagamento'}</button>}</div></div>)}</div></div>}
          {purchaseMessage && <p className="mt-4 rounded-xl bg-white p-3 text-sm font-semibold text-pink-700">{purchaseMessage}</p>}
          {(productShop.purchases || []).length > 0 && <div className="mt-5 rounded-2xl border border-pink-100 bg-white/80 p-4"><h3 className="text-sm font-black text-zinc-900">Minhas solicitações</h3><div className="mt-3 max-h-[390px] space-y-2 overflow-y-auto overscroll-contain pr-1">{productShop.purchases.map(p => <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-zinc-50 p-3 text-xs"><span className="font-bold">{p.product === 'hydrant' ? 'Hidratante' : 'Stick'} · {brl(p.price)}</span><span className={`rounded-full px-2 py-1 font-black ${p.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : p.status === 'rejected' || p.status === 'cancelled' ? 'bg-pink-100 text-pink-700' : 'bg-amber-100 text-amber-800'}`}>{({pending: p.freight_paid === true ? 'Frete pago · Aguardando envio' : 'Aguardando pagamento do frete',shipped:'Enviado — aguardando aprovação',approved:'Aprovado',rejected:'Recusado',cancelled:'Cancelado'})[p.status] || p.status}</span>{p.tracking_url && ['shipped','approved'].includes(p.status) && <a href={p.tracking_url} target="_blank" rel="noreferrer" className="font-black text-sky-700 underline">Acompanhar entrega ↗</a>}{['pending','shipped'].includes(p.status) && <a href={`https://wa.me/553132784332?text=${encodeURIComponent(`Olá, suporte She. Gostaria de cancelar a solicitação ${p.id} do produto ${p.product === 'hydrant' ? 'Hidratante' : 'Stick'}.`)}`} target="_blank" rel="noreferrer" className="font-bold text-emerald-700 underline">Solicitar cancelamento pelo WhatsApp</a>}</div>)}</div></div>}
        </section>

        {purchaseProduct && <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-zinc-950/60 p-4"><form onSubmit={submitProductPurchase} className="my-auto w-full max-w-xl rounded-3xl bg-white p-5 shadow-2xl md:p-7"><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] font-black uppercase tracking-widest text-pink-500">Finalizar solicitação</p><h2 className="mt-1 text-xl font-black text-zinc-950">Dados para entrega</h2><p className="mt-1 text-xs text-zinc-500">O valor será reservado. O abatimento definitivo acontece após a aprovação da She.</p></div><button type="button" onClick={() => setPurchaseProduct('')} className="rounded-full bg-zinc-100 px-3 py-1 text-sm font-black">✕</button></div><div className="mt-5 grid gap-3 sm:grid-cols-2">
          {[['name','Nome completo','text'],['cpf','CPF','text'],['cep','CEP','text'],['email','E-mail','email'],['phone','Telefone','tel']].map(([key,label,type]) => <label key={key} className="grid gap-1 text-xs font-bold text-zinc-600">{label}<input required value={purchaseForm[key]} onChange={e=>setPurchaseForm(v=>({...v,[key]:key === 'cep' ? e.target.value.replace(/[^0-9-]/g, '').slice(0, 9) : e.target.value}))} type={type} inputMode={key === 'cep' ? 'numeric' : undefined} maxLength={key === 'cep' ? 9 : undefined} placeholder={key === 'cep' ? '00000-000' : ''} className="rounded-xl border border-zinc-200 px-3 py-3 text-sm font-medium text-zinc-900 outline-none focus:border-pink-400" /></label>)}
          {purchaseCepLoading && <p className="sm:col-span-2 text-xs font-semibold text-pink-600">Buscando endereço pelo CEP…</p>}
          {purchaseCepError && <p className="sm:col-span-2 text-xs font-semibold text-red-600">{purchaseCepError}</p>}
          <label className="grid gap-1 text-xs font-bold text-zinc-600">Estado<input required readOnly value={purchaseForm.state} className="rounded-xl border border-zinc-200 bg-zinc-50 px-3 py-3 text-sm font-medium text-zinc-900" placeholder="UF preenchida pelo CEP" /></label>
          <label className="grid gap-1 text-xs font-bold text-zinc-600">Cidade<input required readOnly value={purchaseForm.city} className="rounded-xl border border-zinc-200 bg-zinc-50 px-3 py-3 text-sm font-medium text-zinc-900" placeholder="Preenchida pelo CEP" /></label>
          <label className="grid gap-1 text-xs font-bold text-zinc-600">Bairro<input required value={purchaseForm.neighborhood} onChange={e=>setPurchaseForm(v=>({...v,neighborhood:e.target.value}))} className="rounded-xl border border-zinc-200 px-3 py-3 text-sm font-medium text-zinc-900 outline-none focus:border-pink-400" /></label>
          <label className="grid gap-1 text-xs font-bold text-zinc-600">Rua<input required value={purchaseForm.street} onChange={e=>setPurchaseForm(v=>({...v,street:e.target.value}))} className="rounded-xl border border-zinc-200 px-3 py-3 text-sm font-medium text-zinc-900 outline-none focus:border-pink-400" /></label>
          <label className="grid gap-1 text-xs font-bold text-zinc-600">Número da residência<input required value={purchaseForm.number} onChange={e=>setPurchaseForm(v=>({...v,number:e.target.value}))} className="rounded-xl border border-zinc-200 px-3 py-3 text-sm font-medium text-zinc-900 outline-none focus:border-pink-400" placeholder="Nº" /></label>
          <label className="grid gap-1 text-xs font-bold text-zinc-600">Complemento (opcional)<input value={purchaseForm.complement} onChange={e=>setPurchaseForm(v=>({...v,complement:e.target.value}))} className="rounded-xl border border-zinc-200 px-3 py-3 text-sm font-medium text-zinc-900 outline-none focus:border-pink-400" placeholder="Apto, bloco…" /></label>
          <label className="grid gap-1 text-xs font-bold text-zinc-600 sm:col-span-2">Observações<textarea value={purchaseForm.notes} onChange={e=>setPurchaseForm(v=>({...v,notes:e.target.value}))} rows={2} className="rounded-xl border border-zinc-200 px-3 py-3 text-sm font-medium text-zinc-900 outline-none focus:border-pink-400" /></label></div>
          <p className="mt-4 rounded-xl bg-pink-50 p-3 text-sm font-black text-pink-800">{purchaseProduct === 'hydrant' ? 'Hidratante' : 'Stick'} · {brl(purchaseProduct === 'hydrant' ? productShop.prices?.hydrant : productShop.prices?.stick)}</p>
          <button disabled={purchaseBusy || purchaseCepLoading || !purchaseForm.state || !purchaseForm.city || !purchaseForm.street || !purchaseForm.number} className="mt-4 w-full rounded-xl bg-pink-600 px-4 py-3 font-black text-white disabled:opacity-50">{purchaseBusy ? 'Enviando solicitação…' : 'Confirmar solicitação'}</button></form></div>}

        <section className="mt-6 rounded-[1.5rem] bg-white p-6 border border-pink-100 shadow-sm">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="font-black text-xl">Movimentações de saldo</h2>
              <p className="mt-1 text-sm text-zinc-400">Saques, impulsos e compras de produtos de todo o período.</p>
            </div>
            <span className="rounded-full bg-zinc-50 px-3 py-1 text-xs font-black text-zinc-500">{(dashboard?.movements || []).length} movimentação(ões)</span>
          </div>

          <div className="mt-5 max-h-[500px] space-y-3 overflow-y-auto pr-1">
            {[...(dashboard?.movements || [])]
              .sort((a, b) => {
                const dateA = new Date(a.date || a.requested_at || a.created_at || 0).getTime();
                const dateB = new Date(b.date || b.requested_at || b.created_at || 0).getTime();
                const safeA = Number.isFinite(dateA) ? dateA : 0;
                const safeB = Number.isFinite(dateB) ? dateB : 0;
                return safeB - safeA || String(b.id || '').localeCompare(String(a.id || ''));
              })
              .map(movement => (
              <div key={movement.id} className="flex flex-col gap-3 rounded-2xl border border-zinc-100 bg-zinc-50/70 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-full ${movement.kind === 'boost' ? 'bg-emerald-100 text-emerald-600' : 'bg-pink-100 text-pink-600'}`}>{movement.kind === 'boost' ? '↗' : '↗'}</div>
                  <div>
                    <p className="font-black text-zinc-900">{movement.kind === 'boost' ? 'Impulso de Equipe' : movement.kind === 'product_purchase' ? `Compra Loja de Benefícios · ${movement.productPurchase?.product === 'hydrant' ? 'Hidratante' : 'Stick'}` : `Solicitação de Saque ${movement.source === 'team' ? '· Equipe' : '· Pessoal'}`}</p>
                    <p className="mt-0.5 text-xs text-zinc-400">{new Date(movement.date).toLocaleDateString('pt-BR')}</p>
                    {movement.kind === 'withdrawal' && movement.status === 'rejected' && (
                       <p className="mt-1 max-w-xl text-xs font-semibold leading-5 text-red-600"><strong>Motivo da recusa:</strong> {movement.withdrawal?.note || 'Solicitação de saque recusada.'}</p>
                     )}
                  </div>
                </div>
                <div className="flex items-center gap-3 sm:justify-end">
                  <span className="text-lg font-black text-zinc-950">{brl(movement.amount)}</span>
                  <span className={`rounded-full px-3 py-1 text-[11px] font-black ${movement.kind === 'boost' ? (movement.status === 'active' ? 'bg-emerald-100 text-emerald-800' : movement.status === 'cancelled' ? 'bg-zinc-200 text-zinc-700' : movement.status === 'completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800') : movement.kind === 'product_purchase' ? (movement.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : ['rejected','cancelled'].includes(movement.status) ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800') : (movement.status === 'pending' ? 'bg-amber-100 text-amber-800' : movement.status === 'processing' ? 'bg-blue-100 text-blue-800' : movement.status === 'paid' ? 'bg-emerald-100 text-emerald-800' : movement.status === 'failed' || movement.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-zinc-200 text-zinc-700')}`}>
                    {movement.kind === 'boost' ? boostStatusLabel(movement.status) : movement.kind === 'product_purchase' ? productPurchaseStatusLabel(movement.status, movement.productPurchase?.freight_paid === true) : withdrawalStatusLabel(movement.status)}
                  </span>
                </div>
              </div>
            ))}
            {!dashboard?.movements?.length && (
              <div className="rounded-2xl border border-dashed border-zinc-200 px-4 py-8 text-center text-sm text-zinc-400">Nenhuma movimentação ainda.</div>
            )}
          </div>
        </section>

        <div className="mt-8 mb-2 flex flex-wrap items-center justify-end gap-2 border-t border-pink-100/80 pt-5">
          <button type="button" onClick={openProfile} className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-[11px] font-black text-zinc-700 transition hover:border-pink-300 hover:text-pink-600 md:text-xs">Meus Dados</button>
          <button type="button" onClick={logout} className="rounded-lg bg-zinc-950 px-3 py-2 text-[11px] font-black text-white transition hover:bg-zinc-800 md:text-xs">Sair</button>
        </div>

        <footer className="relative mt-10 overflow-hidden rounded-[2rem] bg-[#0b0b0d] px-6 pt-12 pb-7 text-white shadow-sm md:px-10">
          <div className="absolute -top-32 left-1/2 h-[260px] w-[620px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_top,#3A1835_0%,#170D16_42%,rgba(9,8,10,0)_78%)] blur-[80px] pointer-events-none" />
          <div className="relative grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
            <div>
              <p className="text-lg font-black">She</p>
              <p className="mt-3 max-w-sm text-sm leading-6 text-white/55">Programa de afiliadas SHE. Uma parceria comercial independente para divulgação dos nossos produtos.</p>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-pink-300">Navegue</p>
              <nav className="mt-4 flex flex-col gap-3 text-sm text-white/70">
                <Link to="/afiliado" className="hover:text-white transition-colors">Área da Afiliada</Link>
                <Link to="/representantes" className="hover:text-white transition-colors">Representantes</Link>
              </nav>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-pink-300">Legal</p>
              <nav className="mt-4 flex flex-col gap-3 text-sm text-white/70">
                <Link to="/termos-afiliadas" className="hover:text-white transition-colors">Termos de Afiliadas</Link>
                <Link to="/politica-de-privacidade" className="hover:text-white transition-colors">Política de Privacidade</Link>
                <Link to="/termos-de-uso" className="hover:text-white transition-colors">Termos de Uso</Link>
              </nav>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-pink-300">Contato</p>
              <a href="https://wa.me/553132784332" target="_blank" rel="noreferrer" className="mt-4 inline-flex text-sm text-white/70 hover:text-white transition-colors">Fale com a gente</a>
            </div>
          </div>
          <div className="relative mt-10 border-t border-white/10 pt-5 text-xs text-white/35">© {new Date().getFullYear()} She. Todos os direitos reservados.</div>
        </footer>
      </div>


      {profileOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/45 px-5 py-8" onMouseDown={event => { if (event.target === event.currentTarget && !profileBusy) setProfileOpen(false) }}>
            <div className="w-full max-w-lg rounded-[2rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.25)]">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-black uppercase tracking-[.22em] text-pink-500">Minha conta</p>
                  <h3 className="mt-1 text-2xl font-black text-zinc-950">Meus Dados</h3>
                  <p className="mt-1 text-sm text-zinc-400">Confira e altere seus dados de cadastro.</p>
                </div>
                <button type="button" disabled={profileBusy} onClick={() => setProfileOpen(false)} className="h-9 w-9 rounded-full bg-zinc-100 text-zinc-500 disabled:opacity-50">×</button>
              </div>

              <form onSubmit={saveProfile} className="mt-6 space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block sm:col-span-2">
                    <span className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">E-mail</span>
                    <input value={profileForm.email} onChange={e => setProfileForm(current => ({ ...current, email: e.target.value }))} type="email" required autoComplete="email" className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-3 text-sm font-semibold outline-none focus:border-pink-400" />
                  </label>
                  <label className="block">
                    <span className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">CPF</span>
                    <input value={profileForm.cpf} onChange={e => setProfileForm(current => ({ ...current, cpf: e.target.value.replace(/\D/g, '').slice(0, 11) }))} inputMode="numeric" maxLength={11} required className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-3 text-sm font-semibold outline-none focus:border-pink-400" />
                  </label>
                  <label className="block">
                    <span className="text-[10px] font-black uppercase tracking-[.15em] text-zinc-400">WhatsApp</span>
                    <input value={profileForm.whatsapp} onChange={e => setProfileForm(current => ({ ...current, whatsapp: e.target.value }))} type="tel" required autoComplete="tel" className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-3 text-sm font-semibold outline-none focus:border-pink-400" />
                  </label>
                </div>

                <div className="border-t border-zinc-100 pt-4">
                  <p className="text-sm font-black text-zinc-900">Alterar senha</p>
                  <p className="mt-1 text-xs text-zinc-400">Deixe em branco para manter a senha atual.</p>
                  <input value={profileForm.password} onChange={e => setProfileForm(current => ({ ...current, password: e.target.value }))} type="password" minLength={8} autoComplete="new-password" placeholder="Nova senha (mín. 8 caracteres)" className="mt-3 w-full rounded-xl border border-zinc-200 px-3 py-3 text-sm font-semibold outline-none focus:border-pink-400" />
                </div>

                {profileMessage && <p className="rounded-xl bg-zinc-50 px-3 py-2.5 text-xs font-semibold text-zinc-600">{profileMessage}</p>}
                <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                  <button type="button" disabled={profileBusy} onClick={() => setProfileOpen(false)} className="rounded-xl border border-zinc-200 px-4 py-3 text-sm font-black text-zinc-600 disabled:opacity-50">Fechar</button>
                  <button type="submit" disabled={profileBusy} className="rounded-xl bg-zinc-950 px-5 py-3 text-sm font-black text-white transition hover:bg-pink-500 disabled:opacity-50">{profileBusy ? 'Salvando…' : 'Salvar alterações'}</button>
                </div>
              </form>
            </div>
          </div>
        )}

      {videoTermsOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 px-5 py-8" onMouseDown={event => { if (event.target === event.currentTarget && !videoBusy) setVideoTermsOpen(false) }}>
          <div role="dialog" aria-modal="true" className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-[2rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.3)]">
            <div className="flex items-start justify-between gap-4"><div><p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Termos e Condições · versão 1.0</p><h3 className="mt-1 text-2xl font-black text-zinc-950">Autorização de uso do vídeo</h3></div><button type="button" disabled={videoBusy} onClick={() => setVideoTermsOpen(false)} className="h-9 w-9 rounded-full bg-zinc-100 text-zinc-500">×</button></div>
            <div className="mt-5 space-y-3 text-sm leading-6 text-zinc-600">
              <p>Ao aceitar, você declara que possui os direitos necessários sobre o vídeo enviado ou autorização suficiente para conceder esta licença à SHE.</p>
              <p>Você autoriza a SHE, de forma gratuita, a reproduzir, publicar, editar, cortar, adaptar, legendar, redimensionar e divulgar o vídeo em canais próprios e em campanhas de tráfego pago, inclusive utilizando o seu link de afiliada para atribuição das vendas.</p>
              <p>A autorização inclui o uso do vídeo em anúncios, redes sociais, páginas, criativos e outros formatos de divulgação relacionados à SHE, pelo período em que a SHE considerar necessário para suas ações de marketing.</p>
              <p>Você declara ser responsável por obter as autorizações de qualquer pessoa, música, imagem, marca ou outro material de terceiros presente no vídeo. Caso exista alguma restrição, você deve informá-la antes do envio.</p>
              <p>A aprovação não obriga a SHE a utilizar o vídeo. A SHE poderá interromper ou retirar a divulgação a qualquer momento, sem obrigação de pagamento adicional, royalties ou indenização pelo uso autorizado.</p>
              <p>Você permanece livre para manter e utilizar o vídeo em seus próprios canais, salvo se houver obrigação diferente decorrente de direitos de terceiros.</p>
              <p>Você concorda que o aceite destes termos, associado ao seu cadastro e à data/hora do envio, será registrado para comprovar a autorização concedida.</p>
            </div>
            <label className="mt-5 flex cursor-pointer gap-3 rounded-2xl border border-pink-100 bg-pink-50/60 p-4"><input type="checkbox" checked={videoTermsAccepted} onChange={e => setVideoTermsAccepted(e.target.checked)} className="mt-1 h-4 w-4 accent-pink-500" /><span className="text-sm font-bold leading-5 text-zinc-700">Li e aceito integralmente os Termos e Condições para publicação e divulgação do vídeo.</span></label>
            <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button type="button" disabled={videoBusy} onClick={() => setVideoTermsOpen(false)} className="rounded-xl border border-zinc-200 px-5 py-3 text-sm font-black text-zinc-600">Cancelar</button><button type="button" disabled={!videoTermsAccepted || videoBusy} onClick={submitVideo} className="rounded-xl bg-zinc-950 px-5 py-3 text-sm font-black text-white disabled:cursor-not-allowed disabled:opacity-40">{videoBusy ? 'Enviando…' : 'Aceitar e enviar'}</button></div>
          </div>
        </div>
      )}

      {videoHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/35 px-5 py-8 backdrop-blur-[2px]" onMouseDown={() => setVideoHelpOpen(false)}>
          <div role="dialog" aria-modal="true" aria-labelledby="video-help-title" className="w-full max-w-md rounded-[1.5rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.22)]" onMouseDown={event => event.stopPropagation()}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Divulgue seu vídeo</p>
                <h3 id="video-help-title" className="mt-1 text-xl font-black text-zinc-950">Como funciona</h3>
              </div>
              <button type="button" aria-label="Fechar" onClick={() => setVideoHelpOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-sm font-black text-zinc-500 transition hover:bg-pink-50 hover:text-pink-500">×</button>
            </div>
            <div className="mt-5 text-sm leading-6 text-zinc-600">
              <p>Crie e publique seu vídeo, depois envie o link aqui. A She vai analisar. Se aprovado, poderemos usar o vídeo em divulgação usando o seu link, ajudando a gerar vendas para você sem custo de mídia para a afiliada.</p>
            </div>
            <button type="button" onClick={() => setVideoHelpOpen(false)} className="mt-6 w-full rounded-xl bg-zinc-950 py-3 font-black text-white transition hover:bg-pink-500">Entendi</button>
          </div>
        </div>
      )}

        </div>

      {teamConfirmOpen && teamConfirmParent && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/40 px-4 py-6 backdrop-blur-[3px]" onMouseDown={event => { if (event.target === event.currentTarget) closeTeamConfirmation() }}>
          <div role="dialog" aria-modal="true" aria-labelledby="team-confirm-title" className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-[1.8rem] bg-white p-5 shadow-[0_30px_100px_rgba(0,0,0,.28)] sm:p-7" onMouseDown={event => event.stopPropagation()}>
            <div className="flex items-start justify-between gap-4">
              <div><p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Confirmação de equipe</p><h3 id="team-confirm-title" className="mt-1 text-2xl font-black text-zinc-950">Confirmar entrada na equipe</h3><p className="mt-1 text-sm leading-5 text-zinc-500">Confira quem será sua afiliada mãe e leia as condições antes de confirmar sua entrada.</p></div>
              <button type="button" aria-label="Fechar confirmação" onClick={closeTeamConfirmation} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-lg font-black text-zinc-500 hover:bg-pink-50 hover:text-pink-600">×</button>
            </div>

            <div className="mt-5 rounded-[1.4rem] border border-pink-100 bg-gradient-to-br from-pink-50 via-white to-rose-50 p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-pink-100 bg-white text-xl font-black text-pink-500 shadow-sm">{String(teamConfirmParent.name || teamConfirmParent.parentName || 'A').trim().charAt(0).toUpperCase()}</div>
                <div className="min-w-0 flex-1"><p className="text-[10px] font-black uppercase tracking-[.16em] text-pink-500">Sua afiliada mãe será</p><h4 className="mt-1 break-words text-lg font-black text-zinc-950">{teamConfirmParent.name || teamConfirmParent.parentName || 'Afiliada SHE'}</h4><p className="mt-0.5 text-xs font-semibold text-zinc-400">ID {teamConfirmParent.id || teamConfirmParent.parentId}</p></div>
              </div>

            </div>

            <div className="mt-4 flex items-center gap-3 rounded-[1.2rem] border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 p-4">
              <img src="/badge-bronze.svg" alt="Broche Bronze" className="h-14 w-14 shrink-0 object-contain drop-shadow-sm" />
              <div><p className="text-[10px] font-black uppercase tracking-[.17em] text-amber-700">Benefício de entrada</p><p className="mt-1 text-lg font-black leading-tight text-zinc-950">Ganhe 30 dias de Qualificação Bronze</p><p className="mt-1 text-xs leading-5 text-zinc-600">O prazo é de 30 dias corridos, contados a partir da confirmação da entrada na equipe.</p></div>
            </div>

            <div className="mt-5 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
              <p className="text-xs font-black uppercase tracking-[.15em] text-zinc-500">Condições para entrar na equipe</p>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-5 text-zinc-700">
                <li>Ao confirmar a entrada, você ficará vinculada à afiliada mãe exibida acima.</li>
                <li>Depois de entrar em uma equipe, não será possível sair dela nem trocar de afiliada mãe.</li>
                <li>Você receberá 30 dias corridos de Qualificação Bronze, contados a partir da confirmação da entrada na equipe.</li>
              </ul>
              <p className="mt-3 text-xs leading-5 text-zinc-500">Ao clicar em “Aceitar e entrar na equipe”, você declara que leu, compreendeu e aceita estas condições.</p>
            </div>

            <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button type="button" disabled={teamJoinBusy} onClick={closeTeamConfirmation} className="rounded-xl border border-zinc-200 px-5 py-3 text-sm font-black text-zinc-600 disabled:opacity-50">Voltar</button><button type="button" disabled={teamJoinBusy} onClick={confirmTeamJoin} className="rounded-xl bg-pink-500 px-5 py-3 text-sm font-black text-white shadow-md shadow-pink-100 transition hover:bg-pink-600 disabled:cursor-not-allowed disabled:opacity-40">{teamJoinBusy ? 'Confirmando…' : 'Aceitar e entrar na equipe'}</button></div>
          </div>
        </div>
      )}

      {boostConfirmPlan && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/45 px-4 py-6 backdrop-blur-[2px]" onMouseDown={() => { if (!teamBoostBusy) { setBoostConfirmPlan(null); setBoostTermsAccepted(false) } }}>
          <div role="dialog" aria-modal="true" aria-labelledby="boost-confirm-title" className="w-full max-w-lg rounded-[1.7rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.25)]" onMouseDown={event => event.stopPropagation()}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Confirmação de contratação</p>
                <h3 id="boost-confirm-title" className="mt-1 text-xl font-black text-zinc-950">Confirmar Impulso de Equipe</h3>
                <p className="mt-2 text-sm text-zinc-500">Plano de {boostConfirmPlan.connections} conexões · <strong className="text-pink-600">{brl(boostConfirmPlan.price)}</strong></p>
              </div>
              <button type="button" aria-label="Fechar" onClick={() => { setBoostConfirmPlan(null); setBoostTermsAccepted(false) }} disabled={teamBoostBusy} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-sm font-black text-zinc-500 disabled:opacity-50">×</button>
            </div>
            <div className="mt-5 space-y-3 rounded-2xl border border-pink-100 bg-pink-50/60 p-4 text-sm leading-6 text-zinc-700">
              <p>Ao contratar o Impulso, o valor será reservado do seu saldo e você entrará na fila. Quando houver capacidade, o sistema ativará o plano e direcionará novas afiliadas para você conforme elas procurarem uma equipe.</p>
              <p>Quando novas afiliadas entrarem na sua equipe, você poderá entrar em contato com elas para dar boas-vindas, apresentar a oportunidade e incentivá-las a desenvolver as vendas.</p>
              <p><strong className="text-zinc-900">Cancelamento:</strong> enquanto estiver na fila, você pode sair e receber o valor reservado de volta. Depois que o impulso for ativado, não há cancelamento nem reembolso.</p>
              <p>As conexões representam novas entradas confirmadas na equipe, e o impulso termina quando todas as conexões contratadas forem utilizadas.</p>
            </div>
            <label className="mt-5 flex cursor-pointer items-start gap-3 rounded-xl border border-zinc-200 p-4 text-sm leading-5 text-zinc-700">
              <input type="checkbox" checked={boostTermsAccepted} onChange={event => setBoostTermsAccepted(event.target.checked)} className="mt-1 h-4 w-4 accent-pink-500" />
              <span>Li e aceito os termos do Impulso de Equipe, incluindo as regras de reserva do saldo, fila, cancelamento e reembolso.</span>
            </label>
            <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <button type="button" disabled={teamBoostBusy} onClick={() => { setBoostConfirmPlan(null); setBoostTermsAccepted(false) }} className="rounded-xl border border-zinc-200 px-5 py-3 text-sm font-black text-zinc-600 disabled:opacity-50">Voltar</button>
              <button type="button" disabled={!boostTermsAccepted || teamBoostBusy} onClick={async () => { const planKey = boostConfirmPlan.key; const success = await purchaseBoost(planKey); if (success) { setBoostConfirmPlan(null); setBoostTermsAccepted(false) } }} className="rounded-xl bg-pink-500 px-5 py-3 text-sm font-black text-white shadow-md shadow-pink-100 transition hover:bg-pink-600 disabled:cursor-not-allowed disabled:bg-zinc-300">{teamBoostBusy ? 'Processando…' : 'Aceitar termos e contratar'}</button>
            </div>
          </div>
        </div>
      )}

      {boostHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/35 px-5 py-8 backdrop-blur-[2px]" onMouseDown={() => setBoostHelpOpen(false)}>
          <div role="dialog" aria-modal="true" aria-labelledby="boost-help-title" className="w-full max-w-lg rounded-[1.7rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.22)]" onMouseDown={event => event.stopPropagation()}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Impulsionar Equipe</p>
                <h3 id="boost-help-title" className="mt-1 text-xl font-black text-zinc-950">Como funciona</h3>
              </div>
              <button type="button" aria-label="Fechar" onClick={() => setBoostHelpOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-sm font-black text-zinc-500 transition hover:bg-pink-50 hover:text-pink-500">×</button>
            </div>
            <div className="mt-5 rounded-[1.5rem] bg-zinc-950 p-5 text-sm leading-6 text-white/75">
              <p><strong className="text-white">1.</strong> Escolha um plano de impulsionamento.</p>
              <p className="mt-3"><strong className="text-white">2.</strong> O valor é reservado do seu saldo e você entra em uma fila única.</p>
              <p className="mt-3"><strong className="text-white">3.</strong> Quando houver capacidade, o impulso é ativado.</p>
              <p className="mt-3"><strong className="text-white">4.</strong> Cada nova entrada confirmada consome uma conexão.</p>
              <p className="mt-3"><strong className="text-white">5.</strong> Ao terminar as conexões, o impulso é concluído automaticamente.</p>
            </div>
            <div className="mt-5 space-y-3 text-sm leading-6 text-zinc-600">
              <p><strong className="text-zinc-900">Enquanto estiver na fila:</strong> você pode sair e receber o saldo reservado de volta.</p>
              <p><strong className="text-zinc-900">Depois que o impulso é ativado:</strong> não há cancelamento nem reembolso.</p>
              <p>As novas afiliadas são distribuídas entre os impulsos ativos conforme a capacidade do sistema.</p>
            </div>
            <button type="button" onClick={() => setBoostHelpOpen(false)} className="mt-6 w-full rounded-xl bg-zinc-950 py-3 font-black text-white transition hover:bg-pink-500">Entendi</button>
          </div>
        </div>
      )}

      {fixedHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/35 px-5 py-8 backdrop-blur-[2px]" onMouseDown={() => setFixedHelpOpen(false)}>
          <div role="dialog" aria-modal="true" aria-labelledby="fixed-help-title" className="w-full max-w-md rounded-[1.5rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.22)]" onMouseDown={event => event.stopPropagation()}>
            <div className="flex items-start justify-between gap-4">
              <div><p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Bônus Fixo</p><h3 id="fixed-help-title" className="mt-1 text-xl font-black text-zinc-950">Metas acumuladas</h3></div>
              <button type="button" aria-label="Fechar" onClick={() => setFixedHelpOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-sm font-black text-zinc-500">×</button>
            </div>
            <div className="mt-5 space-y-4 text-sm leading-6 text-zinc-600">
              <p>O Bônus Fixo considera todas as suas vendas acumuladas. Ao atingir a meta de Bronze, Prata ou Ouro, esse nível fica permanente.</p>
              <p>Hoje as metas são <strong>{config.fixedLevels?.bronze || 100}</strong> vendas para Bronze, <strong>{config.fixedLevels?.silver || 300}</strong> para Prata e <strong>{config.fixedLevels?.gold || 500}</strong> para Ouro.</p>
              <p>O nível fixo funciona como um piso do Bônus Mensal: mesmo que um novo mês comece com poucas vendas, você mantém o nível fixo que já conquistou até alcançar o próximo.</p>
            </div>
            <button type="button" onClick={() => setFixedHelpOpen(false)} className="mt-6 w-full rounded-xl bg-zinc-950 py-3 font-black text-white transition hover:bg-pink-500">Entendi</button>
          </div>
        </div>
      )}

      {welcomeLinkOpen && hasAffiliateLink && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-zinc-950/60 px-4 py-5 backdrop-blur-md" onMouseDown={event => { if (event.target === event.currentTarget) setWelcomeLinkOpen(false) }}>
          <div role="dialog" aria-modal="true" aria-labelledby="welcome-link-title" className="relative max-h-[94vh] w-full max-w-xl overflow-y-auto rounded-[2rem] border border-pink-100 bg-white shadow-[0_30px_100px_rgba(0,0,0,.32)]">
            <div className="relative overflow-hidden bg-gradient-to-br from-pink-600 via-fuchsia-500 to-rose-400 px-6 pb-7 pt-8 text-center text-white sm:px-8">
              <div className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 rounded-full bg-white/15 blur-2xl" />
              <div className="relative mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-white/40 bg-white/20 text-4xl shadow-lg">♡</div>
              <p className="relative mt-4 text-[10px] font-black uppercase tracking-[.25em] text-white/85">She Afiliadas</p>
              <h2 id="welcome-link-title" className="relative mt-2 text-3xl font-black sm:text-4xl">Bem-vinda à SHE!</h2>
              <p className="relative mx-auto mt-2 max-w-sm text-sm leading-6 text-white/95">Seu link de afiliada está pronto. Agora você pode começar a divulgar e construir sua jornada com a gente.</p>
            </div>
            <div className="space-y-5 p-5 sm:p-7">
              <div className="rounded-2xl border border-pink-200 bg-gradient-to-r from-pink-50 to-rose-50 p-4">
                <p className="text-[10px] font-black uppercase tracking-[.18em] text-pink-600">Seu link exclusivo</p>
                <div className="mt-2 flex items-center gap-2">
                  <p className="min-w-0 flex-1 break-all text-sm font-black text-zinc-800">{publicUrl}</p>
                  <button type="button" aria-label="Copiar link de afiliada" title="Copiar link" onClick={async () => { try { await navigator.clipboard.writeText(publicUrl); setWelcomeLinkCopyMessage('Link copiado!'); } catch { setWelcomeLinkCopyMessage('Não foi possível copiar automaticamente. Selecione e copie o link.'); } }} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-pink-200 bg-white text-pink-600 shadow-sm transition hover:bg-pink-100">
                    <svg viewBox="0 0 24 24" aria-hidden="true" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>
                  </button>
                </div>
                {welcomeLinkCopyMessage && <p aria-live="polite" className="mt-2 text-[11px] font-bold text-pink-700">{welcomeLinkCopyMessage}</p>}
                <p className="mt-2 text-xs leading-5 text-zinc-500">Envie esse link para alguém comprar um produto She Coisa de Mulher ou para uma pessoa se cadastrar como afiliada diretamente na sua equipe.</p>
              </div>

              <div className="rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50 via-white to-orange-50 p-4">
                <div className="flex items-start gap-3">
                  <img src="/badge-bronze.svg" alt="Benefício Bronze" className="h-12 w-12 shrink-0 object-contain" />
                  <div><h3 className="text-base font-black text-zinc-950">Comece entrando em uma equipe</h3><p className="mt-1 text-xs leading-5 text-zinc-600">Ao entrar em uma equipe, você recebe o benefício de Qualificação Bronze por 30 dias corridos. Sua afiliada mãe também pode orientar você nos primeiros passos.</p></div>
                </div>
                <form onSubmit={joinTeam} className="mt-4">
                  <label htmlFor="welcome-team-code" className="block text-xs font-black text-zinc-800">Você tem o ID da afiliada que gostaria de acompanhar?</label>
                  <input id="welcome-team-code" value={teamCode} onChange={e => { setTeamCode(e.target.value.replace(/\D/g, '').slice(0, 12)); setTeamLookup(null); setTeamLookupMessage(''); setTeamJoinMessage('') }} disabled={teamJoinBusy || Boolean(teamReservation)} inputMode="numeric" placeholder="Digite o ID da afiliada" className="mt-2 w-full rounded-xl border border-zinc-200 bg-white px-4 py-3 text-sm font-bold outline-none transition focus:border-pink-400 focus:ring-2 focus:ring-pink-100" />
                  {teamCode && !teamReservation && <div className={`mt-2 rounded-xl border px-3 py-2.5 text-xs ${teamLookup ? 'border-pink-200 bg-pink-50 text-zinc-700' : 'border-zinc-100 bg-zinc-50 text-zinc-500'}`} aria-live="polite">{teamLookupBusy ? 'Buscando afiliada pelo ID…' : teamLookup ? <>Você entrará na equipe de <strong className="text-zinc-950">{teamLookup.name}</strong> <span className="text-zinc-400">(ID {teamLookup.id})</span>.</> : teamLookupMessage || 'Digite o ID para localizar a afiliada.'}</div>}
                  {teamReservation && <p className="mt-2 rounded-xl border border-pink-200 bg-pink-50 px-3 py-2.5 text-xs text-zinc-700">Equipe encontrada: <strong>{teamReservation.parentName}</strong> (ID {teamReservation.parentId}).</p>}
                  {teamJoinMessage && <p className="mt-2 text-xs font-semibold text-zinc-600">{teamJoinMessage}</p>}
                  {teamBoostMessage && <p className="mt-2 text-xs font-semibold text-zinc-600">{teamBoostMessage}</p>}
                  <button type="submit" disabled={teamJoinBusy || teamLookupBusy || !teamCode || !teamLookup || Number(teamLookup.id) !== Number(teamCode) || Boolean(teamReservation)} className="mt-3 w-full rounded-xl bg-pink-500 px-4 py-3 text-sm font-black text-white shadow-md shadow-pink-100 transition hover:bg-pink-600 disabled:cursor-not-allowed disabled:opacity-40">Revisar e entrar na equipe</button>
                </form>
                <button type="button" onClick={findTeam} disabled={teamBoostBusy || Boolean(teamReservation)} className="mt-2 w-full rounded-xl border border-pink-200 bg-white px-4 py-3 text-sm font-black text-pink-600 transition hover:bg-pink-50 disabled:cursor-not-allowed disabled:opacity-50">{teamBoostBusy ? 'Encontrando equipe…' : 'Não tenho um ID — encontrar equipe'}</button>
                <button type="button" onClick={() => setWelcomeLinkOpen(false)} className="mt-2 w-full rounded-xl px-4 py-2.5 text-sm font-bold text-zinc-500 transition hover:bg-zinc-50">Agora não</button>
                <p className="mt-3 text-center text-[10px] leading-4 text-zinc-400">Importante: depois da sua primeira venda aprovada, não será mais possível entrar em uma equipe. Você poderá continuar divulgando seu link normalmente.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {welcomeMotherOpen && team.parent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-zinc-950/55 px-4 py-8 backdrop-blur-sm" onMouseDown={event => { if (event.target === event.currentTarget) setWelcomeMotherOpen(false) }}>
          <div role="dialog" aria-modal="true" aria-labelledby="welcome-mother-title" className="relative w-full max-w-md overflow-hidden rounded-[2rem] border border-pink-100 bg-white shadow-[0_30px_100px_rgba(0,0,0,.28)]">
            <div className="bg-gradient-to-br from-pink-500 via-fuchsia-500 to-rose-400 px-6 pb-8 pt-8 text-center text-white">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-white/40 bg-white/20 text-3xl shadow-lg">♡</div>
              <p className="mt-4 text-[10px] font-black uppercase tracking-[.25em] text-white/80">Bem-vinda à SHE</p>
              <h2 id="welcome-mother-title" className="mt-2 text-3xl font-black">Você não está sozinha!</h2>
              <p className="mx-auto mt-2 max-w-xs text-sm leading-6 text-white/90">Sua jornada começa com uma parceria. Conheça a afiliada que te trouxe para nossa equipe.</p>
            </div>
            <div className="px-6 py-6 text-center">
              <p className="text-xs font-bold uppercase tracking-[.16em] text-zinc-400">Sua afiliada mãe</p>
              <p className="mt-2 text-2xl font-black text-zinc-950">{team.parent.name}</p>
              <p className="mt-2 text-sm leading-6 text-zinc-500">Ela pode te orientar e ajudar nos seus primeiros passos como afiliada.</p>
              {team.parent.whatsapp && (() => {
                const digits = String(team.parent.whatsapp).replace(/\D/g, '')
                const number = digits.startsWith('55') ? digits : `55${digits}`
                const message = `Oi, ${team.parent.name}! Acabei de me cadastrar como afiliada da SHE pelo seu link. 💗`
                return <a href={`https://wa.me/${number}?text=${encodeURIComponent(message)}`} target="_blank" rel="noreferrer" className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-[#25D366] px-5 py-4 text-sm font-black text-white shadow-lg shadow-emerald-500/20 transition hover:bg-[#1fb85a]"><svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5" fill="currentColor"><path d="M20.52 3.48A11.86 11.86 0 0 0 12.08 0C5.47 0 .1 5.37.1 11.98c0 2.11.55 4.17 1.6 5.99L0 24l6.2-1.63a11.94 11.94 0 0 0 5.88 1.5h.01c6.61 0 11.98-5.37 11.98-11.98 0-3.2-1.25-6.2-3.55-8.41ZM12.09 21.8a9.9 9.9 0 0 1-5.04-1.38l-.36-.21-3.68.97.98-3.59-.23-.37a9.83 9.83 0 0 1-1.51-5.24c0-5.44 4.43-9.87 9.88-9.87a9.8 9.8 0 0 1 6.98 2.89 9.8 9.8 0 0 1 2.89 6.99c0 5.44-4.43 9.87-9.89 9.87Z"/></svg>Conversar com {team.parent.name} no WhatsApp</a>
              })()}
              <button type="button" onClick={() => setWelcomeMotherOpen(false)} className="mt-3 w-full rounded-2xl bg-zinc-950 px-5 py-3.5 text-sm font-black text-white transition hover:bg-zinc-800">Começar minha jornada</button>
              <p className="mt-3 text-[11px] text-zinc-400">Esta mensagem de boas-vindas aparece apenas uma vez.</p>
            </div>
          </div>
        </div>
      )}

      {levelHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/35 px-5 py-8 backdrop-blur-[2px]" onMouseDown={() => setLevelHelpOpen(false)}>
          <div role="dialog" aria-modal="true" aria-labelledby="level-help-title" className="w-full max-w-md rounded-[1.5rem] bg-white p-6 shadow-[0_30px_100px_rgba(0,0,0,.22)]" onMouseDown={event => event.stopPropagation()}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[.2em] text-pink-500">Como funcionam os níveis</p>
                <h3 id="level-help-title" className="mt-1 text-xl font-black text-zinc-950">Pontos e retroatividade</h3>
              </div>
              <button type="button" aria-label="Fechar" onClick={() => setLevelHelpOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-sm font-black text-zinc-500 transition hover:bg-pink-50 hover:text-pink-500">×</button>
            </div>
            <div className="mt-5 space-y-4 text-sm leading-6 text-zinc-600">
              <p>Os pontos do mês são a soma das suas vendas com as vendas das afiliadas diretamente na sua equipe. O progresso reinicia no dia 1 de cada mês, à 00:00, mas nunca fica abaixo do seu Bônus Fixo.</p>
              <p>Os níveis atingidos são retroativos às vendas do mês: ao alcançar um novo nível, todas as vendas daquele mês passam a receber o valor por pedido daquele nível.</p>
              <p>Ao entrar em uma equipe, o bônus de Bronze dura exatamente 30 dias corridos a partir da data e hora do cadastro na equipe. Ele não termina na virada do mês. Quando os 30 dias acabam, o bônus é retirado e o nível volta imediatamente ao progresso real do mês, respeitando o Bônus Fixo já conquistado.</p>
            </div>
            <button type="button" onClick={() => setLevelHelpOpen(false)} className="mt-6 w-full rounded-xl bg-zinc-950 py-3 font-black text-white transition hover:bg-pink-500">Entendi</button>
          </div>
        </div>
      )}
    </main>
  )
}
