import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { rememberAffiliate } from '../utils/affiliateTracking'
import logo from '../assets/she-logo.webp'

const options = [
  {
    label: 'Tenho ressecamento, dor, candidíase.',
    path: '/hidratante',
  },
  {
    label: 'Desejo clarear a pele, manchas, cicatrizes, melasma.',
    path: '/stick',
  },
]

export default function Welcome({ affiliateSlug = null, affiliate = null }) {
  const navigate = useNavigate()
  useEffect(() => { if (affiliateSlug) rememberAffiliate(affiliateSlug) }, [affiliateSlug])
  const [name, setName] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const savedName = localStorage.getItem('sheVisitorName')
    if (savedName) setName(savedName)

    const timer = window.setTimeout(() => setIsLoading(false), 900)
    return () => window.clearTimeout(timer)
  }, [])

  const handleChoice = (path) => {
    const cleanName = name.trim()
    if (cleanName) localStorage.setItem('sheVisitorName', cleanName)
    const affiliatePath = affiliateSlug ? `/${affiliateSlug}${path}` : path
    navigate(affiliatePath)
  }

  if (isLoading) {
    return (
      <main className="min-h-screen bg-[#fffafc] flex flex-col items-center justify-center px-5">
        <div className="flex flex-col items-center w-full max-w-[220px]">
          <img
            src={logo}
            alt="She"
            className="w-36 md:w-44 opacity-0 animate-[sheLogoIn_0.7s_ease-out_forwards]"
            loading="eager"
          />
          <div className="mt-8 h-1 w-full overflow-hidden rounded-full bg-pink-100">
            <div className="h-full w-0 rounded-full bg-pink-500 animate-[sheLoader_0.8s_ease-out_0.15s_forwards]" />
          </div>
        </div>
        <style>{`
          @keyframes sheLogoIn {
            from { opacity: 0; transform: translateY(10px) scale(0.97); }
            to { opacity: 0.9; transform: translateY(0) scale(1); }
          }
          @keyframes sheLoader {
            from { width: 0%; }
            to { width: 100%; }
          }
        `}</style>
      </main>
    )
  }

  return (
    <>
      <div className="fixed right-4 top-4 z-50 sm:right-6 sm:top-6">
        <button type="button" aria-expanded={menuOpen} aria-label="Abrir menu" onClick={() => setMenuOpen(v => !v)} className="flex items-center gap-2 rounded-full border border-pink-100 bg-white/95 px-4 py-2.5 text-sm font-bold text-zinc-800 shadow-lg backdrop-blur hover:border-pink-300">
          <span className="text-pink-500">☰</span> Menu <span className="text-xs text-pink-500">{menuOpen ? '⌃' : '⌄'}</span>
        </button>
        {menuOpen && <div className="absolute right-0 mt-2 w-60 overflow-hidden rounded-2xl border border-pink-100 bg-white p-2 shadow-2xl">
          <button onClick={() => { setMenuOpen(false); handleChoice('/hidratante') }} className="w-full rounded-xl px-3 py-3 text-left text-sm font-semibold hover:bg-pink-50">Hidratante Íntimo</button>
          <button onClick={() => { setMenuOpen(false); handleChoice('/stick') }} className="w-full rounded-xl px-3 py-3 text-left text-sm font-semibold hover:bg-pink-50">Stick Clareador de Pele</button>
          <div className="my-1 border-t border-pink-100" />
          <button onClick={() => { setMenuOpen(false); navigate('/minhas-compras') }} className="w-full rounded-xl px-3 py-3 text-left text-sm font-bold text-pink-600 hover:bg-pink-50">Minhas Compras</button>
        </div>}
      </div>
      <main className="she-welcome-page min-h-screen bg-[#fffafc] flex items-center justify-center px-4 py-4 sm:px-5 sm:py-6">
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[620px] h-[420px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(251,207,232,0.42)_0%,rgba(251,207,232,0)_70%)]" />
          <div className="absolute bottom-[-180px] left-[-100px] w-[420px] h-[420px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(255,228,230,0.42)_0%,rgba(255,228,230,0)_70%)]" />
        </div>

        <section className="she-welcome-card relative z-10 w-full max-w-xl rounded-[1.75rem] md:rounded-[2.5rem] bg-white/80 backdrop-blur-xl border border-white shadow-[0_30px_100px_rgba(0,0,0,0.10)] px-5 py-6 sm:px-6 sm:py-8 md:px-10 md:py-12">
          <div className="flex justify-center mb-5 sm:mb-6">
            <img src={logo} alt="She" className="w-32 sm:w-36 md:w-52 opacity-90" loading="eager" />
          </div>

          <div className="text-center">
            <h1 className="text-[2rem] sm:text-3xl md:text-5xl font-black tracking-tight text-zinc-950 leading-[1.05]">
              O que a trouxe
              <br />
              até aqui?
            </h1>

            <p className="mt-3 sm:mt-4 text-sm md:text-base text-zinc-500">
              Antes de continuar, queremos conhecer você.
            </p>
          </div>

          <div className="mt-5 sm:mt-6">
            <label htmlFor="she-name" className="block text-xs font-semibold text-zinc-500 mb-2 ml-1">
              Qual seu nome?
            </label>

            <input
              id="she-name"
              type="text"
              value={name}
              onChange={(event) => setName(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  event.preventDefault()
                  document.getElementById('she-options')?.focus()
                }
              }}
              placeholder="Digite seu nome"
              autoComplete="given-name"
              className="w-full rounded-2xl border border-zinc-200 bg-white px-4 py-3 text-base text-zinc-900 outline-none transition-all placeholder:text-zinc-400 focus:border-pink-400 focus:ring-4 focus:ring-pink-100"
            />
          </div>

          <div id="she-options" className="mt-5 space-y-5">
            {options.map((option, index) => (
              <div key={option.label}>
                <p className="mb-2 px-1 text-center text-[11px] font-black uppercase tracking-[.16em] text-pink-500">
                  {index === 0 ? 'Hidratante Íntimo' : 'Stick Clareador de Pele'}
                </p>
                <button
                  type="button"
                  onClick={() => handleChoice(option.path)}
                  className={`w-full text-left rounded-2xl px-4 py-3.5 md:py-4 border transition-all duration-300 active:scale-[0.985] ${
                    index === 0
                      ? 'border-pink-200 bg-pink-50/70 hover:bg-pink-50 hover:border-pink-300'
                      : 'border-zinc-200 bg-white hover:bg-zinc-50 hover:border-zinc-300'
                  }`}
                >
                  <span className="flex items-center justify-between gap-4">
                    <span className="text-sm md:text-[15px] font-semibold leading-snug text-zinc-900">
                      {option.label}
                    </span>
                    <span className="text-zinc-400 text-lg shrink-0">→</span>
                  </span>
                </button>
              </div>
            ))}
          </div>

          <p className="mt-5 text-center text-[10px] md:text-xs text-zinc-400">
            Sua experiência será personalizada de acordo com sua escolha.
          </p>

          <div className="mt-5 flex items-center justify-between px-1">
            <a
              href="/programa-afiliadas"
              className="text-xs font-medium text-zinc-400 transition-colors hover:text-zinc-600"
            >
              Afiliadas
            </a>
            <a
              href="/revendedora"
              className="text-xs font-medium text-zinc-400 transition-colors hover:text-zinc-600"
            >
              Revendedora
            </a>
          </div>
        </section>
      </main>
      <style>{`
        /* A welcome deve ocupar a viewport sem criar scroll no documento.
           Os espaçamentos diminuem conforme a altura disponível, para evitar cortes em celulares. */
        .she-welcome-page {
          height: 100vh;
          height: 100dvh;
          min-height: 0;
          overflow: hidden;
          box-sizing: border-box;
          padding-top: max(12px, env(safe-area-inset-top));
          padding-bottom: max(12px, env(safe-area-inset-bottom));
        }
        .she-welcome-card {
          max-height: calc(100dvh - 24px);
          overflow-y: auto;
          overscroll-behavior: contain;
          scrollbar-width: none;
          padding-top: clamp(12px, 3.2dvh, 48px);
          padding-bottom: clamp(12px, 3.2dvh, 48px);
        }
        .she-welcome-card::-webkit-scrollbar { display: none; }
        .she-welcome-card > div:first-child { margin-bottom: clamp(8px, 1.8dvh, 24px); }
        .she-welcome-card > div:first-child img { width: clamp(76px, 13dvh, 208px); }
        .she-welcome-card h1 { font-size: clamp(1.45rem, 4.8dvh, 3rem); }
        .she-welcome-card p { line-height: 1.35; }
        .she-welcome-card input { padding-top: clamp(8px, 1.5dvh, 12px); padding-bottom: clamp(8px, 1.5dvh, 12px); }
        .she-welcome-card #she-options { margin-top: clamp(10px, 2dvh, 24px); gap: clamp(8px, 1.8dvh, 20px); }
        .she-welcome-card #she-options button { padding-top: clamp(9px, 1.6dvh, 16px); padding-bottom: clamp(9px, 1.6dvh, 16px); }
        @media (max-height: 650px) {
          .she-welcome-card { border-radius: 22px; }
          .she-welcome-card > div:first-child { margin-bottom: 8px; }
          .she-welcome-card .mt-5 { margin-top: 10px; }
          .she-welcome-card .mt-3 { margin-top: 8px; }
          .she-welcome-card #she-options > div > p { margin-bottom: 5px; }
          .she-welcome-card .text-center > p { font-size: 12px; }
          .she-welcome-card > p:last-of-type { margin-top: 10px; }
          .she-welcome-card > div:last-child { margin-top: 10px; }
        }
      `}</style>
    </>
  )
}
